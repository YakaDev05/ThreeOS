"""
Тесты для AccountServer (server/threeos_server.py) — регистрация,
аутентификация, доставка/очередь сообщений. Сервер написан на чистом
stdlib (asyncio), поэтому эти тесты не требуют Qt/GUI вообще.
"""
import asyncio
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from server.threeos_server import AccountServer, hash_password


class TestAccountServerLogic(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.data_file = self.tmp_dir / "server_test.json"
        if self.data_file.exists():
            self.data_file.unlink()
        self.server = AccountServer(data_file=self.data_file)

    def tearDown(self):
        if self.data_file.exists():
            self.data_file.unlink()

    def test_register_new_account(self):
        ok, reason = self.server.register("+70001112233", "secret", "Алиса")
        self.assertTrue(ok)
        self.assertIn("+70001112233", self.server.accounts)

    def test_cannot_register_same_phone_twice(self):
        self.server.register("+70001112233", "secret", "Алиса")
        ok, reason = self.server.register("+70001112233", "other", "Кто-то ещё")
        self.assertFalse(ok)

    def test_register_requires_phone_and_password(self):
        ok, _ = self.server.register("", "secret", "Имя")
        self.assertFalse(ok)
        ok, _ = self.server.register("+7000", "", "Имя")
        self.assertFalse(ok)

    def test_authenticate_correct_password(self):
        self.server.register("+70001112233", "secret", "Алиса")
        self.assertTrue(self.server.authenticate("+70001112233", "secret"))

    def test_authenticate_wrong_password(self):
        self.server.register("+70001112233", "secret", "Алиса")
        self.assertFalse(self.server.authenticate("+70001112233", "wrong"))

    def test_authenticate_unknown_phone(self):
        self.assertFalse(self.server.authenticate("+79999999999", "anything"))

    def test_passwords_are_hashed_not_plaintext(self):
        self.server.register("+70001112233", "secret", "Алиса")
        stored = self.server.accounts["+70001112233"]
        self.assertNotEqual(stored["hash"], "secret")
        self.assertEqual(stored["hash"], hash_password("secret", stored["salt"]))

    def test_deliver_to_unregistered_phone_fails(self):
        self.server.register("+70001112233", "secret", "Алиса")
        ok, queued = asyncio.run(self.server.deliver_or_queue("+70001112233", "+79999999999", "hi", "id1"))
        self.assertFalse(ok)

    def test_message_queues_when_recipient_offline(self):
        self.server.register("+70001112233", "secret", "Алиса")
        self.server.register("+70009998877", "secret2", "Боб")
        ok, queued = asyncio.run(self.server.deliver_or_queue("+70001112233", "+70009998877", "hi bob", "id1"))
        self.assertTrue(ok)
        self.assertTrue(queued)
        pending = self.server.pop_queued("+70009998877")
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]["text"], "hi bob")

    def test_persistence_across_instances(self):
        self.server.register("+70001112233", "secret", "Алиса")
        reloaded = AccountServer(data_file=self.data_file)
        self.assertIn("+70001112233", reloaded.accounts)
        self.assertTrue(reloaded.authenticate("+70001112233", "secret"))


if __name__ == "__main__":
    unittest.main()
