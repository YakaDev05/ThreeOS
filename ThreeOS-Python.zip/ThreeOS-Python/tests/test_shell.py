"""
Автоматические тесты для VirtualFileSystem и ShellInterpreter.
Не требуют GUI — вся логика Терминала тестируется отдельно от интерфейса.
Каждый тест использует свой временный JSON-файл, чтобы не трогать
настоящие файлы пользователя в ~/.threeos.

Запуск из корня проекта:
    python -m unittest discover -v
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PySide6.QtCore import QCoreApplication

if QCoreApplication.instance() is None:
    _app = QCoreApplication(sys.argv[:1])

from apps.terminal.virtual_file_system import VirtualFileSystem
from apps.terminal.shell_interpreter import ShellInterpreter


def _make_fs(tmp_dir: Path, name: str) -> VirtualFileSystem:
    data_file = tmp_dir / name
    if data_file.exists():
        data_file.unlink()
    return VirtualFileSystem(data_file=data_file)


class TestVirtualFileSystem(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.fs = _make_fs(self.tmp_dir, "vfs_test.json")
        self.home = self.fs.default_start_path()

    def tearDown(self):
        data_file = self.tmp_dir / "vfs_test.json"
        if data_file.exists():
            data_file.unlink()

    def test_default_layout(self):
        self.assertEqual(self.home, "/home/user")
        self.assertIn("readme.txt", self.fs.list(self.home))

    def test_mkdir_and_normalize(self):
        self.assertTrue(self.fs.make_directory(self.home, "projects"))
        new_cwd = self.fs.normalize(self.home, "projects")
        self.assertEqual(new_cwd, "/home/user/projects")

    def test_cd_dotdot_and_absolute(self):
        self.fs.make_directory(self.home, "projects")
        inside = self.fs.normalize(self.home, "projects")
        back_up = self.fs.normalize(inside, "..")
        self.assertEqual(back_up, "/home/user")
        to_system = self.fs.normalize(self.home, "/system")
        self.assertEqual(to_system, "/system")

    def test_cd_nonexistent_fails(self):
        self.assertIsNone(self.fs.normalize(self.home, "nope"))

    def test_file_write_read_remove(self):
        self.fs.write_file(self.home, "todo.txt", "Купить молоко")
        content, ok = self.fs.read_file(self.home, "todo.txt")
        self.assertTrue(ok)
        self.assertEqual(content, "Купить молоко")
        self.assertTrue(self.fs.remove_entry(self.home, "todo.txt"))
        _, ok = self.fs.read_file(self.home, "todo.txt")
        self.assertFalse(ok)

    def test_no_duplicate_names(self):
        self.assertTrue(self.fs.make_directory(self.home, "dup"))
        self.assertFalse(self.fs.make_directory(self.home, "dup"))

    def test_rename_entry(self):
        self.fs.create_file(self.home, "old.txt", "данные")
        self.assertTrue(self.fs.rename_entry(self.home, "old.txt", "new.txt"))
        self.assertFalse(self.fs.exists(self.home, "old.txt"))
        content, ok = self.fs.read_file(self.home, "new.txt")
        self.assertTrue(ok)
        self.assertEqual(content, "данные")

    def test_copy_file(self):
        self.fs.create_file(self.home, "a.txt", "содержимое")
        self.assertTrue(self.fs.copy_file(self.home, "a.txt", "b.txt"))
        content_a, _ = self.fs.read_file(self.home, "a.txt")
        content_b, _ = self.fs.read_file(self.home, "b.txt")
        self.assertEqual(content_a, content_b)

    def test_find_across_tree(self):
        self.fs.create_file(self.home, "budget.txt")
        self.fs.make_directory(self.home, "budget_folder")
        matches = self.fs.find("budget")
        self.assertIn("/home/user/budget.txt", matches)
        self.assertIn("/home/user/budget_folder", matches)

    def test_tree_contains_children(self):
        self.fs.make_directory(self.home, "sub")
        self.fs.create_file("/home/user/sub", "inner.txt")
        rendered = self.fs.tree(self.home)
        self.assertIn("sub/", rendered)
        self.assertIn("inner.txt", rendered)

    def test_separate_windows_have_independent_cwd(self):
        """Ключевая проверка архитектуры: VFS сама не хранит cwd, поэтому
        два 'окна' с разными cwd не влияют друг на друга."""
        window_a_cwd = self.home
        window_b_cwd = self.fs.normalize(self.home, "..")  # /home/user -> /home
        self.fs.create_file(window_a_cwd, "only_in_a.txt")
        self.assertIn("only_in_a.txt", self.fs.list(window_a_cwd))
        self.assertNotIn("only_in_a.txt", self.fs.list(window_b_cwd))


class TestShellInterpreter(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.fs = _make_fs(self.tmp_dir, "shell_test.json")
        self.shell = ShellInterpreter(self.fs)

    def tearDown(self):
        data_file = self.tmp_dir / "shell_test.json"
        if data_file.exists():
            data_file.unlink()

    def test_pwd(self):
        out, clear = self.shell.execute("pwd")
        self.assertEqual(out, "/home/user")
        self.assertFalse(clear)

    def test_echo_redirect_and_cat(self):
        self.shell.execute("echo Привет > hello.txt")
        out, _ = self.shell.execute("cat hello.txt")
        self.assertEqual(out, "Привет")

    def test_unknown_command(self):
        out, _ = self.shell.execute("bla-bla-bla")
        self.assertIn("Команда не найдена", out)

    def test_clear_flag(self):
        out, clear = self.shell.execute("clear")
        self.assertEqual(out, "")
        self.assertTrue(clear)

    def test_cd_error_message(self):
        out, _ = self.shell.execute("cd nowhere")
        self.assertIn("не найдена", out)

    def test_mv(self):
        self.shell.execute("touch a.txt")
        out, _ = self.shell.execute("mv a.txt b.txt")
        self.assertEqual(out, "")
        ls_out, _ = self.shell.execute("ls")
        self.assertIn("b.txt", ls_out)
        self.assertNotIn("a.txt", ls_out)

    def test_cp(self):
        self.shell.execute("echo hello > a.txt")
        self.shell.execute("cp a.txt b.txt")
        out, _ = self.shell.execute("cat b.txt")
        self.assertEqual(out, "hello")

    def test_find(self):
        self.shell.execute("touch alpha.txt")
        out, _ = self.shell.execute("find alpha")
        self.assertIn("alpha.txt", out)

    def test_tree(self):
        self.shell.execute("mkdir sub")
        out, _ = self.shell.execute("tree")
        self.assertIn("sub/", out)

    def test_wc(self):
        self.shell.execute("echo one two three > words.txt")
        out, _ = self.shell.execute("wc words.txt")
        self.assertIn("3 слов", out)

    def test_head_and_tail(self):
        self.shell.execute("echo line1 > f.txt")  # только одна строка технически, но проверим общий путь
        out, _ = self.shell.execute("head f.txt 1")
        self.assertEqual(out, "line1")
        out2, _ = self.shell.execute("tail f.txt 1")
        self.assertEqual(out2, "line1")

    def test_grep(self):
        self.shell.execute("echo яблоко груша банан > fruit.txt")
        out, _ = self.shell.execute("grep груша fruit.txt")
        self.assertIn("груша", out)

    def test_history(self):
        self.shell.execute("pwd")
        self.shell.execute("whoami")
        out, _ = self.shell.execute("history")
        self.assertIn("pwd", out)
        self.assertIn("whoami", out)

    def test_calc_basic(self):
        out, _ = self.shell.execute("calc 2+2*2")
        self.assertIn("= 6", out)

    def test_calc_rejects_unsafe_input(self):
        out, _ = self.shell.execute("calc __import__('os')")
        self.assertIn("не удалось вычислить", out)

    def test_man_known_command(self):
        out, _ = self.shell.execute("man grep")
        self.assertIn("grep", out.lower())

    def test_cwd_persists_across_commands_in_same_session(self):
        self.shell.execute("mkdir sub")
        self.shell.execute("cd sub")
        out, _ = self.shell.execute("pwd")
        self.assertEqual(out, "/home/user/sub")


if __name__ == "__main__":
    unittest.main()
