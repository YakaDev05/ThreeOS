"""
Автоматические тесты для ContactsStore и MessagesStore.
Каждый тест использует свой временный JSON-файл, чтобы не трогать
настоящие данные пользователя в ~/.threeos и не зависеть друг от друга.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# QObject-based классы (сигналы) должны создаваться при существующем
# QCoreApplication — GUI при этом не нужен.
from PySide6.QtCore import QCoreApplication

if QCoreApplication.instance() is None:
    _app = QCoreApplication(sys.argv[:1])

from services.contacts_store import ContactsStore
from services.messages_store import MessagesStore


class TestContactsStore(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.data_file = self.tmp_dir / "contacts_test.json"
        if self.data_file.exists():
            self.data_file.unlink()
        self.store = ContactsStore(data_file=self.data_file)

    def tearDown(self):
        if self.data_file.exists():
            self.data_file.unlink()

    def test_seeds_demo_contacts_when_empty(self):
        self.assertGreater(len(self.store.all()), 0)

    def test_add_contact(self):
        before = len(self.store.all())
        contact = self.store.add("Тестовый Контакт", phone="+7 000 000 0000")
        self.assertEqual(len(self.store.all()), before + 1)
        self.assertEqual(self.store.get(contact.id).name, "Тестовый Контакт")

    def test_update_contact(self):
        contact = self.store.add("До Изменения")
        ok = self.store.update(contact.id, name="После изменения", phone="+7 111 111 1111")
        self.assertTrue(ok)
        updated = self.store.get(contact.id)
        self.assertEqual(updated.name, "После изменения")
        self.assertEqual(updated.phone, "+7 111 111 1111")

    def test_update_missing_contact_returns_false(self):
        self.assertFalse(self.store.update("no-such-id", name="X"))

    def test_remove_contact(self):
        contact = self.store.add("Временный")
        self.assertTrue(self.store.remove(contact.id))
        self.assertIsNone(self.store.get(contact.id))

    def test_persistence_across_instances(self):
        contact = self.store.add("Сохранённый", phone="+7 222 222 2222")
        contact_id = contact.id
        # Новый экземпляр, читающий тот же файл, должен увидеть те же данные.
        reloaded = ContactsStore(data_file=self.data_file)
        found = reloaded.get(contact_id)
        self.assertIsNotNone(found)
        self.assertEqual(found.name, "Сохранённый")

    def test_initial_letter(self):
        contact = self.store.add("яна")
        self.assertEqual(contact.initial(), "Я")


class TestMessagesStore(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.data_file = self.tmp_dir / "messages_test.json"
        if self.data_file.exists():
            self.data_file.unlink()
        self.store = MessagesStore(data_file=self.data_file)

    def tearDown(self):
        if self.data_file.exists():
            self.data_file.unlink()

    def test_empty_thread_by_default(self):
        self.assertEqual(self.store.thread("some-contact"), [])
        self.assertIsNone(self.store.last_message("some-contact"))

    def test_send_and_receive(self):
        self.store.send("c1", "Привет!")
        self.store.receive("c1", "И тебе привет!")
        thread = self.store.thread("c1")
        self.assertEqual(len(thread), 2)
        self.assertTrue(thread[0].outgoing)
        self.assertFalse(thread[1].outgoing)

    def test_last_message(self):
        self.store.send("c1", "первое")
        self.store.send("c1", "второе")
        self.assertEqual(self.store.last_message("c1").text, "второе")

    def test_threads_are_independent(self):
        self.store.send("c1", "для первого")
        self.store.send("c2", "для второго")
        self.assertEqual(len(self.store.thread("c1")), 1)
        self.assertEqual(len(self.store.thread("c2")), 1)

    def test_persistence_across_instances(self):
        self.store.send("c1", "сохранится ли это?")
        reloaded = MessagesStore(data_file=self.data_file)
        self.assertEqual(len(reloaded.thread("c1")), 1)
        self.assertEqual(reloaded.thread("c1")[0].text, "сохранится ли это?")

    def test_update_status_resolves_pending_message(self):
        msg = self.store.send("c1", "проверка", delivered=False, pending=True)
        self.assertTrue(msg.pending)
        ok = self.store.update_status("c1", msg.id, delivered=True, queued=False)
        self.assertTrue(ok)
        updated = self.store.thread("c1")[0]
        self.assertFalse(updated.pending)
        self.assertTrue(updated.delivered)
        self.assertFalse(updated.queued)

    def test_update_status_unknown_message_returns_false(self):
        self.assertFalse(self.store.update_status("c1", "no-such-id", delivered=True))


if __name__ == "__main__":
    unittest.main()
