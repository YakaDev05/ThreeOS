"""
Тесты для Identity и "чистой" логики NetworkService (разбор пакетов,
отслеживание пиров, устаревание) — без проверки настоящей доставки по сети
(это внешняя инфраструктура ОС, а не наш код; сетевой протокол был отдельно
проверен вручную двумя реальными процессами при разработке).
"""
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PySide6.QtCore import QCoreApplication

if QCoreApplication.instance() is None:
    _app = QCoreApplication(sys.argv[:1])

from services.identity import Identity
from services.network_service import NetworkService, PEER_TIMEOUT_MS

_TEST_PORT_COUNTER = [52100]  # чтобы разные тесты не конфликтовали портами TCP


def _next_test_port() -> int:
    _TEST_PORT_COUNTER[0] += 1
    return _TEST_PORT_COUNTER[0]


class TestIdentity(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.data_file = self.tmp_dir / "identity_test.json"
        if self.data_file.exists():
            self.data_file.unlink()

    def tearDown(self):
        if self.data_file.exists():
            self.data_file.unlink()

    def test_creates_persistent_device_id(self):
        identity = Identity(data_file=self.data_file)
        self.assertTrue(identity.device_id)
        self.assertTrue(identity.display_name)

    def test_device_id_stable_across_instances(self):
        first = Identity(data_file=self.data_file)
        device_id = first.device_id
        second = Identity(data_file=self.data_file)
        self.assertEqual(second.device_id, device_id)

    def test_set_display_name_persists(self):
        identity = Identity(data_file=self.data_file)
        identity.set_display_name("Тестовое Имя")
        reloaded = Identity(data_file=self.data_file)
        self.assertEqual(reloaded.display_name, "Тестовое Имя")

    def test_blank_name_is_ignored(self):
        identity = Identity(data_file=self.data_file)
        original = identity.display_name
        identity.set_display_name("   ")
        self.assertEqual(identity.display_name, original)


class TestNetworkServicePeerLogic(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.identity_file = self.tmp_dir / f"identity_net_{_next_test_port()}.json"
        self.identity = Identity(data_file=self.identity_file)
        self.service = NetworkService(messaging_port=_next_test_port(), identity=self.identity)

    def tearDown(self):
        if self.identity_file.exists():
            self.identity_file.unlink()

    def test_starts_with_no_peers(self):
        self.assertEqual(self.service.peers(), {})
        self.assertFalse(self.service.is_online("anyone"))

    def test_handle_datagram_adds_peer(self):
        import json
        payload = json.dumps({"type": "hello", "device_id": "other-1", "name": "Друг", "tcp_port": 9999}).encode()
        self.service._handle_datagram(payload, "10.0.0.5")
        self.assertTrue(self.service.is_online("other-1"))
        peer = self.service.peers()["other-1"]
        self.assertEqual(peer.name, "Друг")
        self.assertEqual(peer.address, "10.0.0.5")
        self.assertEqual(peer.tcp_port, 9999)

    def test_ignores_own_announcements(self):
        import json
        payload = json.dumps({
            "type": "hello", "device_id": self.identity.device_id, "name": "Я сам", "tcp_port": 1,
        }).encode()
        self.service._handle_datagram(payload, "127.0.0.1")
        self.assertEqual(self.service.peers(), {})

    def test_ignores_malformed_datagram(self):
        self.service._handle_datagram(b"not json at all", "10.0.0.5")
        self.assertEqual(self.service.peers(), {})

    def test_stale_peer_is_removed(self):
        import json
        payload = json.dumps({"type": "hello", "device_id": "old-peer", "name": "Старый", "tcp_port": 1}).encode()
        self.service._handle_datagram(payload, "10.0.0.6")
        self.assertTrue(self.service.is_online("old-peer"))

        # искусственно состариваем запись, чтобы не ждать реальные секунды в тесте
        self.service._peers["old-peer"].last_seen_ms -= (PEER_TIMEOUT_MS + 1000)
        self.service._cleanup_stale_peers()
        self.assertFalse(self.service.is_online("old-peer"))

    def test_send_message_to_unknown_peer_fails_gracefully(self):
        self.assertFalse(self.service.send_message("no-such-peer", "привет"))


if __name__ == "__main__":
    unittest.main()
