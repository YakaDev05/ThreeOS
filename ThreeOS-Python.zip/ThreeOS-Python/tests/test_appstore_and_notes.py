"""
Тесты для InstalledAppsStore (Магазин приложений) и NotesStore (Заметки).
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PySide6.QtCore import QCoreApplication

if QCoreApplication.instance() is None:
    _app = QCoreApplication(sys.argv[:1])

from services.installed_apps_store import InstalledAppsStore
from services.notes_store import NotesStore


class TestInstalledAppsStore(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.data_file = self.tmp_dir / "installed_test.json"
        if self.data_file.exists():
            self.data_file.unlink()
        self.store = InstalledAppsStore(data_file=self.data_file)

    def tearDown(self):
        if self.data_file.exists():
            self.data_file.unlink()

    def test_nothing_installed_by_default(self):
        self.assertFalse(self.store.is_installed("notes"))

    def test_install_and_uninstall(self):
        self.store.install("notes")
        self.assertTrue(self.store.is_installed("notes"))
        self.store.uninstall("notes")
        self.assertFalse(self.store.is_installed("notes"))

    def test_persistence_across_instances(self):
        self.store.install("notes")
        reloaded = InstalledAppsStore(data_file=self.data_file)
        self.assertTrue(reloaded.is_installed("notes"))

    def test_double_install_is_harmless(self):
        self.store.install("notes")
        self.store.install("notes")
        self.assertTrue(self.store.is_installed("notes"))


class TestNotesStore(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = Path(__file__).resolve().parent / "_tmp_test_data"
        self.tmp_dir.mkdir(exist_ok=True)
        self.data_file = self.tmp_dir / "notes_test.json"
        if self.data_file.exists():
            self.data_file.unlink()
        self.store = NotesStore(data_file=self.data_file)

    def tearDown(self):
        if self.data_file.exists():
            self.data_file.unlink()

    def test_create_and_get(self):
        note = self.store.create("Заголовок", "Текст")
        fetched = self.store.get(note.id)
        self.assertEqual(fetched.title, "Заголовок")
        self.assertEqual(fetched.body, "Текст")

    def test_update_note(self):
        note = self.store.create("Старый", "старый текст")
        ok = self.store.update(note.id, title="Новый", body="новый текст")
        self.assertTrue(ok)
        updated = self.store.get(note.id)
        self.assertEqual(updated.title, "Новый")
        self.assertEqual(updated.body, "новый текст")

    def test_remove_note(self):
        note = self.store.create("Временная")
        self.assertTrue(self.store.remove(note.id))
        self.assertIsNone(self.store.get(note.id))

    def test_persistence_across_instances(self):
        note = self.store.create("Сохранённая", "содержимое")
        reloaded = NotesStore(data_file=self.data_file)
        fetched = reloaded.get(note.id)
        self.assertIsNotNone(fetched)
        self.assertEqual(fetched.title, "Сохранённая")


if __name__ == "__main__":
    unittest.main()
