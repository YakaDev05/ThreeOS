"""
Точка входа ThreeOS: загружает шрифты, применяет тёмную тему, регистрирует
приложения и показывает экран загрузки -> рабочий стол.
"""
import sys
from pathlib import Path

from PySide6.QtCore import Qt, QCoreApplication

# Должно быть установлено ДО создания QApplication — рекомендация Qt для
# приложений, использующих QtWebEngine (наш Браузер).
QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFontDatabase, QFont, QPalette, QColor

from core.theme import Theme
from shell.app_registry import AppRegistry
from shell.boot_screen import BootScreen
from shell.desktop_window import DesktopWindow

from apps.calculator.calculator_app import CalculatorApp
from apps.terminal.terminal_app import TerminalApp
from apps.browser.browser_app import BrowserApp
from apps.contacts.contacts_app import ContactsApp
from apps.sms.sms_app import SmsApp
from apps.explorer.explorer_app import ExplorerApp
from apps.notes.notes_app import NotesApp
from apps.settings.settings_app import SettingsApp
from apps.appstore.appstore_app import AppStoreApp

from services.contacts_store import ContactsStore
from services.messages_store import MessagesStore
from services.network_service import NetworkService
from services.account_service import AccountService

FONTS_DIR = Path(__file__).resolve().parent / "resources" / "fonts"


def load_fonts():
    """Загружает шрифты из resources/fonts (без встраивания в бинарник —
    в отличие от C++/Qt-версии здесь нет шага компиляции, поэтому шрифты
    просто читаются с диска рядом со скриптом)."""
    for filename in ("JetBrainsMono-Regular.ttf", "JetBrainsMono-Bold.ttf", "Sora.ttf", "Inter-Regular.ttf"):
        QFontDatabase.addApplicationFont(str(FONTS_DIR / filename))


def apply_dark_theme(app: QApplication):
    app.setStyle("Fusion")

    pal = QPalette()
    pal.setColor(QPalette.ColorRole.Window, Theme.bg_base)
    pal.setColor(QPalette.ColorRole.WindowText, Theme.text_primary)
    pal.setColor(QPalette.ColorRole.Base, Theme.bg_surface)
    pal.setColor(QPalette.ColorRole.AlternateBase, Theme.bg_surface_alt)
    pal.setColor(QPalette.ColorRole.ToolTipBase, Theme.bg_surface_alt)
    pal.setColor(QPalette.ColorRole.ToolTipText, Theme.text_primary)
    pal.setColor(QPalette.ColorRole.Text, Theme.text_primary)
    pal.setColor(QPalette.ColorRole.Button, Theme.bg_surface_alt)
    pal.setColor(QPalette.ColorRole.ButtonText, Theme.text_primary)
    pal.setColor(QPalette.ColorRole.BrightText, Theme.danger)
    pal.setColor(QPalette.ColorRole.Link, Theme.accent2)
    pal.setColor(QPalette.ColorRole.Highlight, Theme.accent)
    pal.setColor(QPalette.ColorRole.HighlightedText, QColor("white"))
    pal.setColor(QPalette.ColorRole.PlaceholderText, Theme.text_muted)
    app.setPalette(pal)

    app.setFont(QFont(Theme.font_ui, 10))

    app.setStyleSheet(
        f"QMdiSubWindow {{ background-color: {Theme.bg_surface.name()}; }}"
        f"QScrollBar:vertical {{ background: {Theme.bg_base.name()}; width: 10px; margin: 0; }}"
        f"QScrollBar::handle:vertical {{ background: {Theme.border.name()}; border-radius: 5px; min-height: 24px; }}"
        f"QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}"
        f"QToolTip {{ background-color: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
        f" border: 1px solid {Theme.border.name()}; padding: 4px; }}"
    )


def register_apps():
    """Регистрирует все приложения ThreeOS в AppRegistry.
    Чтобы добавить новое приложение, достаточно создать класс,
    реализующий IApp, и зарегистрировать его здесь одной строкой."""
    registry = AppRegistry.instance()
    registry.register_app(CalculatorApp())
    registry.register_app(TerminalApp())
    registry.register_app(ExplorerApp())
    registry.register_app(BrowserApp())
    registry.register_app(ContactsApp())
    registry.register_app(SmsApp())
    registry.register_app(SettingsApp())
    registry.register_app(NotesApp())
    registry.register_app(AppStoreApp())


def seed_demo_data():
    """Кладёт приветственное сообщение в переписку с системным контактом
    'ThreeOS', чтобы СМС не выглядели пустыми при первом запуске."""
    messages = MessagesStore.instance()
    for contact in ContactsStore.instance().all():
        if contact.name == "ThreeOS" and not messages.thread(contact.id):
            messages.receive(contact.id, "Добро пожаловать в ThreeOS! Открой Контакты — там будут видны другие "
                                          "запущенные ThreeOS в этой сети, их можно добавить и переписываться по-настоящему.")


def handle_incoming_network_message(from_device_id: str, from_name: str, text: str):
    """Приходит из NetworkService, когда реальный человек с другого ThreeOS
    в сети отправил сообщение. Работает независимо от того, открыто ли
    сейчас окно СМС — сообщение не потеряется."""
    contacts = ContactsStore.instance()
    contact = contacts.find_by_device_id(from_device_id)
    if contact is None:
        contact = contacts.add(from_name, device_id=from_device_id)
    MessagesStore.instance().receive(contact.id, text)


def handle_incoming_account_message(from_phone: str, from_name: str, text: str):
    """Приходит из AccountService, когда реальный человек с другого ThreeOS
    (через сервер, по номеру телефона) отправил сообщение — независимо от
    того, в одной вы локальной сети или нет."""
    contacts = ContactsStore.instance()
    contact = contacts.find_by_phone(from_phone)
    if contact is None:
        contact = contacts.add(from_name, phone=from_phone)
    MessagesStore.instance().receive(contact.id, text)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("ThreeOS")
    app.setOrganizationName("Said (Yaka) Hamidov")

    load_fonts()
    apply_dark_theme(app)
    register_apps()
    seed_demo_data()

    # Запускаем обнаружение в сети и приём сообщений сразу при старте —
    # чтобы нас было видно другим и мы не пропустили входящие сообщения,
    # даже если окно СМС ещё не открыто.
    network = NetworkService.instance()
    network.message_received.connect(handle_incoming_network_message)

    account = AccountService.instance()
    account.message_received.connect(handle_incoming_account_message)

    boot = BootScreen()
    desktop = DesktopWindow()

    def on_boot_finished():
        boot.close()
        desktop.showMaximized()

    boot.boot_finished.connect(on_boot_finished)
    boot.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
