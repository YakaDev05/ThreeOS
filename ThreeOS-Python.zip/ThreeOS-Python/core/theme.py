"""
Единая палитра и типографика ThreeOS.
Вся визуальная идентичность системы держится на этих токенах —
поменяв значения здесь, можно перекрасить всю ОС разом.
"""
from PySide6.QtGui import QColor


class Theme:
    # Поверхности
    bg_base = QColor("#0b0e14")        # фон рабочего стола
    bg_surface = QColor("#141922")     # панели, окна приложений
    bg_surface_alt = QColor("#1c2330")  # поднятые/hover-поверхности
    border = QColor("#2a3341")

    # Текст
    text_primary = QColor("#eef1f6")
    text_muted = QColor("#8b98ac")

    # Акценты — два акцентных цвета, а не один, чтобы система читалась
    # как продуманная, а не как "тёмный фон + один яркий цвет"
    accent = QColor("#7c5cff")        # фиолетовый — основной, интерактивные элементы
    accent_hover = QColor("#9177ff")
    accent2 = QColor("#22d3b8")       # мятный — статусы, вторичные акценты
    danger = QColor("#ff6b6b")        # ошибки, удаление

    # Шрифты
    font_display = "Sora"             # заголовки, брендинг
    font_ui = "Inter"                 # интерфейс
    font_mono = "JetBrains Mono"      # терминал
