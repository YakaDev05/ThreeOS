"""
Общий интерфейс для всех приложений ThreeOS.
Каждое приложение регистрируется в AppRegistry и может быть запущено с
рабочего стола, из панели задач или из Магазина приложений — сама оболочка
(DesktopWindow/TaskBar) ничего не знает о конкретных приложениях, она
работает только через этот интерфейс.
"""
from abc import ABC, abstractmethod
from typing import Optional

from PySide6.QtCore import QSize
from PySide6.QtWidgets import QWidget


class IApp(ABC):
    @abstractmethod
    def id(self) -> str:
        """Уникальный идентификатор, напр. 'calculator'."""
        raise NotImplementedError

    @abstractmethod
    def name(self) -> str:
        """Отображаемое имя, напр. 'Калькулятор'."""
        raise NotImplementedError

    @abstractmethod
    def icon_emoji(self) -> str:
        """Иконка (эмодзи, пока нет своих иконок)."""
        raise NotImplementedError

    @abstractmethod
    def description(self) -> str:
        """Краткое описание для Магазина приложений."""
        raise NotImplementedError

    @abstractmethod
    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        """Создаёт новый экземпляр окна приложения.

        context — необязательные данные для открытия приложения в конкретном
        состоянии (например, {'contact_id': ...}, когда СМС открывают из
        Контактов кнопкой «Написать»). Приложения, которым это не нужно,
        просто игнорируют параметр.
        """
        raise NotImplementedError

    def preferred_size(self) -> QSize:
        """Размер окна при первом открытии."""
        return QSize(480, 560)

    def is_core(self) -> bool:
        """True (по умолчанию) — приложение всегда на рабочем столе.
        False — необязательное приложение: появляется на рабочем столе,
        только когда его "устанавливают" через Магазин приложений."""
        return True
