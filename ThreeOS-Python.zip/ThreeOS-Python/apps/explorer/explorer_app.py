"""
Проводник ThreeOS: графический просмотр той же виртуальной файловой
системы, что использует Терминал (общие файлы, отдельный cwd на окно —
см. virtual_file_system.py). Двойной клик по папке — открыть, по файлу —
посмотреть/отредактировать содержимое.
"""
from typing import List, Optional

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QListWidget,
    QListWidgetItem, QDialog, QTextEdit, QInputDialog, QMessageBox,
)

from core.iapp import IApp
from core.theme import Theme
from apps.terminal.virtual_file_system import VirtualFileSystem


class FileViewerDialog(QDialog):
    """Простой просмотрщик/редактор содержимого файла с кнопкой сохранения."""

    def __init__(self, fs: VirtualFileSystem, cwd: str, name: str, parent=None):
        super().__init__(parent)
        self._fs = fs
        self._cwd = cwd
        self._name = name
        self.setWindowTitle(name)
        self.resize(520, 420)
        self.setStyleSheet(f"background-color: {Theme.bg_surface.name()};")

        layout = QVBoxLayout(self)

        content, _ok = fs.read_file(cwd, name)
        self._editor = QTextEdit(self)
        self._editor.setPlainText(content)
        self._editor.setFont(QFont(Theme.font_mono, 10))
        self._editor.setStyleSheet(
            f"QTextEdit {{ background-color: {Theme.bg_base.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 8px; }}"
        )
        layout.addWidget(self._editor)

        btn_row = QHBoxLayout()
        save_btn = QPushButton("Сохранить")
        save_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        save_btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.accent.name()}; color: white; border: none;"
            f" border-radius: 8px; padding: 8px 18px; }}"
            f"QPushButton:hover {{ background: {Theme.accent_hover.name()}; }}"
        )
        save_btn.clicked.connect(self._save)
        close_btn = QPushButton("Закрыть")
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 8px 18px; }}"
        )
        close_btn.clicked.connect(self.close)
        btn_row.addWidget(save_btn)
        btn_row.addWidget(close_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

    def _save(self):
        self._fs.write_file(self._cwd, self._name, self._editor.toPlainText())
        self.close()


class ExplorerWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._fs = VirtualFileSystem.instance()
        self._cwd = self._fs.default_start_path()
        self._history: List[str] = []  # для кнопки "Назад"

        self.setStyleSheet(f"background-color: {Theme.bg_surface.name()};")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        toolbar = QHBoxLayout()
        toolbar.setSpacing(6)
        self._back_btn = self._toolbar_button("←")
        self._up_btn = self._toolbar_button("↑")
        self._new_folder_btn = self._toolbar_button("📁+")
        self._new_file_btn = self._toolbar_button("📄+")
        self._rename_btn = self._toolbar_button("✎")
        self._delete_btn = self._toolbar_button("🗑")

        self._path_label = QLabel()
        self._path_label.setFont(QFont(Theme.font_mono, 10))
        self._path_label.setStyleSheet(f"color: {Theme.text_muted.name()};")

        for b in (self._back_btn, self._up_btn, self._new_folder_btn, self._new_file_btn, self._rename_btn, self._delete_btn):
            toolbar.addWidget(b)
        toolbar.addWidget(self._path_label, 1)
        layout.addLayout(toolbar)

        self._list = QListWidget(self)
        self._list.setViewMode(QListWidget.ViewMode.IconMode)
        self._list.setResizeMode(QListWidget.ResizeMode.Adjust)
        self._list.setIconSize(QSize(1, 1))  # иконки рисуем эмодзи текстом, не картинками
        self._list.setGridSize(QSize(96, 84))
        self._list.setSpacing(6)
        self._list.setMovement(QListWidget.Movement.Static)
        self._list.setStyleSheet(
            "QListWidget { background: transparent; border: none; }"
            f"QListWidget::item {{ color: {Theme.text_primary.name()}; border-radius: 8px; padding: 6px; }}"
            f"QListWidget::item:selected {{ background: {Theme.bg_surface_alt.name()}; }}"
        )
        self._list.itemDoubleClicked.connect(self._on_item_double_clicked)
        layout.addWidget(self._list, 1)

        self._back_btn.clicked.connect(self._go_back)
        self._up_btn.clicked.connect(self._go_up)
        self._new_folder_btn.clicked.connect(self._create_folder)
        self._new_file_btn.clicked.connect(self._create_file)
        self._rename_btn.clicked.connect(self._rename_selected)
        self._delete_btn.clicked.connect(self._delete_selected)

        self._fs.changed.connect(self._refresh)
        self._refresh()

    def _toolbar_button(self, text: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setFixedSize(34, 30)
        btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; }}"
            f"QPushButton:hover {{ background: {Theme.border.name()}; }}"
        )
        return btn

    # ---------- навигация ----------
    def _refresh(self):
        self._path_label.setText(self._cwd)
        self._list.clear()
        for name, is_dir in self._fs.list_entries_detailed(self._cwd):
            icon = "📁" if is_dir else "📄"
            item = QListWidgetItem(f"{icon}\n{name}")
            item.setData(Qt.ItemDataRole.UserRole, (name, is_dir))
            item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter)
            item.setFont(QFont(Theme.font_ui, 9))
            self._list.addItem(item)

    def _navigate(self, new_cwd: str, push_history: bool = True):
        if push_history:
            self._history.append(self._cwd)
        self._cwd = new_cwd
        self._refresh()

    def _go_back(self):
        if self._history:
            self._cwd = self._history.pop()
            self._refresh()

    def _go_up(self):
        parent = self._fs.normalize(self._cwd, "..")
        if parent and parent != self._cwd:
            self._navigate(parent)

    def _on_item_double_clicked(self, item: QListWidgetItem):
        name, is_dir = item.data(Qt.ItemDataRole.UserRole)
        if is_dir:
            target = self._fs.normalize(self._cwd, name)
            if target:
                self._navigate(target)
        else:
            dialog = FileViewerDialog(self._fs, self._cwd, name, self)
            dialog.exec()

    # ---------- операции ----------
    def _selected_name(self) -> Optional[str]:
        items = self._list.selectedItems()
        if not items:
            return None
        name, _is_dir = items[0].data(Qt.ItemDataRole.UserRole)
        return name

    def _create_folder(self):
        name, ok = QInputDialog.getText(self, "Новая папка", "Имя папки:")
        if ok and name.strip():
            if not self._fs.make_directory(self._cwd, name.strip()):
                QMessageBox.warning(self, "Проводник", "Не удалось создать папку (уже существует?)")

    def _create_file(self):
        name, ok = QInputDialog.getText(self, "Новый файл", "Имя файла:")
        if ok and name.strip():
            if not self._fs.create_file(self._cwd, name.strip()):
                QMessageBox.warning(self, "Проводник", "Не удалось создать файл (уже существует?)")

    def _rename_selected(self):
        name = self._selected_name()
        if not name:
            QMessageBox.information(self, "Проводник", "Сначала выберите файл или папку")
            return
        new_name, ok = QInputDialog.getText(self, "Переименовать", "Новое имя:", text=name)
        if ok and new_name.strip() and new_name.strip() != name:
            if not self._fs.rename_entry(self._cwd, name, new_name.strip()):
                QMessageBox.warning(self, "Проводник", "Не удалось переименовать")

    def _delete_selected(self):
        name = self._selected_name()
        if not name:
            QMessageBox.information(self, "Проводник", "Сначала выберите файл или папку")
            return
        confirm = QMessageBox(self)
        confirm.setWindowTitle("Удалить")
        confirm.setText(f"Удалить «{name}»?")
        confirm.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel)
        confirm.setDefaultButton(QMessageBox.StandardButton.Cancel)
        if confirm.exec() == QMessageBox.StandardButton.Yes:
            self._fs.remove_entry(self._cwd, name)


class ExplorerApp(IApp):
    def id(self) -> str:
        return "explorer"

    def name(self) -> str:
        return "Проводник"

    def icon_emoji(self) -> str:
        return "🗂️"

    def description(self) -> str:
        return "Файловый менеджер — та же файловая система, что и в Терминале."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        return ExplorerWidget(parent)

    def preferred_size(self) -> QSize:
        return QSize(620, 480)
