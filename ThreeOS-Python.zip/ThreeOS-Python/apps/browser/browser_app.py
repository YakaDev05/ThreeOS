"""
Браузер ThreeOS: настоящий веб-браузер на движке Chromium (QtWebEngine) —
открывает реальные сайты, переходит по ссылкам, поддерживает вкладки и
историю назад/вперёд. Это не имитация — страницы грузятся из настоящего
интернета через тот же движок, что лежит в основе Chrome/Edge.
"""
from typing import Optional
from urllib.parse import quote

from PySide6.QtCore import QUrl, QSize, Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QTabWidget,
    QProgressBar, QToolButton,
)
from PySide6.QtWebEngineWidgets import QWebEngineView

from core.iapp import IApp
from core.theme import Theme

HOME_URL = "threeos:home"
SEARCH_URL_TEMPLATE = "https://duckduckgo.com/?q={query}"

QUICK_LINKS = [
    ("🔎", "DuckDuckGo", "https://duckduckgo.com"),
    ("📖", "Википедия", "https://ru.wikipedia.org"),
    ("💻", "GitHub", "https://github.com"),
    ("▶️", "YouTube", "https://www.youtube.com"),
]


def _home_html() -> str:
    tiles = "".join(
        f'<a class="tile" href="{url}"><div class="emoji">{emoji}</div><div>{label}</div></a>'
        for emoji, label, url in QUICK_LINKS
    )
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>ThreeOS Браузер</title>
<style>
    body {{
        margin: 0; height: 100vh; display: flex; flex-direction: column;
        align-items: center; justify-content: center;
        background: {Theme.bg_base.name()}; color: {Theme.text_primary.name()};
        font-family: sans-serif;
    }}
    h1 {{ font-weight: 600; margin-bottom: 4px; }}
    p.sub {{ color: {Theme.text_muted.name()}; margin-top: 0; }}
    form {{ margin: 24px 0 32px 0; }}
    input[type=text] {{
        width: 420px; padding: 12px 16px; border-radius: 24px; border: none;
        background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};
        font-size: 14px; outline: none;
    }}
    .tiles {{ display: flex; gap: 18px; }}
    .tile {{
        width: 96px; height: 88px; border-radius: 14px; background: {Theme.bg_surface.name()};
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        text-decoration: none; color: {Theme.text_primary.name()}; font-size: 13px; gap: 8px;
    }}
    .tile:hover {{ background: {Theme.bg_surface_alt.name()}; }}
    .emoji {{ font-size: 28px; }}
</style>
</head>
<body>
    <h1>ThreeOS Браузер</h1>
    <p class="sub">от Said (Yaka) Hamidov</p>
    <form action="https://duckduckgo.com/" method="get">
        <input type="text" name="q" placeholder="Искать в интернете…" autofocus>
    </form>
    <div class="tiles">{tiles}</div>
</body>
</html>"""


def _error_html(attempted_url: str) -> str:
    return f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Не удалось открыть страницу</title>
<style>
    body {{
        margin: 0; height: 100vh; display: flex; flex-direction: column;
        align-items: center; justify-content: center; text-align: center;
        background: {Theme.bg_base.name()}; color: {Theme.text_primary.name()};
        font-family: sans-serif;
    }}
    .icon {{ font-size: 42px; margin-bottom: 8px; }}
    h1 {{ font-size: 18px; font-weight: 600; margin: 0 0 6px 0; }}
    p {{ color: {Theme.text_muted.name()}; margin: 0; max-width: 420px; }}
    code {{ background: {Theme.bg_surface_alt.name()}; padding: 2px 8px; border-radius: 6px; }}
</style>
</head>
<body>
    <div class="icon">🌐</div>
    <h1>Не удалось открыть страницу</h1>
    <p>Проверьте адрес <code>{attempted_url}</code> и подключение к интернету, затем нажмите ⟳, чтобы повторить.</p>
</body>
</html>"""


class BrowserTab(QWebEngineView):
    """QWebEngineView, который умеет открывать ссылки target=_blank и
    window.open() как новую вкладку того же окна браузера, а не как
    неуправляемое всплывающее окно."""

    def __init__(self, browser_widget: "BrowserWidget", parent=None):
        super().__init__(parent)
        self._browser_widget = browser_widget
        self.last_target = ""

    def createWindow(self, _win_type):
        return self._browser_widget.open_new_tab()


class BrowserWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background-color: {Theme.bg_base.name()};")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        toolbar = QHBoxLayout()
        toolbar.setContentsMargins(10, 8, 10, 8)
        toolbar.setSpacing(6)

        self._back_btn = self._nav_button("←")
        self._fwd_btn = self._nav_button("→")
        self._reload_btn = self._nav_button("⟳")
        self._home_btn = self._nav_button("⌂")
        self._new_tab_btn = self._nav_button("+")

        self._url_bar = QLineEdit(self)
        self._url_bar.setFont(QFont(Theme.font_ui, 10))
        self._url_bar.setStyleSheet(
            f"QLineEdit {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 6px 14px; }}"
        )
        self._url_bar.returnPressed.connect(self._navigate_to_bar_text)

        for w in (self._back_btn, self._fwd_btn, self._reload_btn, self._home_btn):
            toolbar.addWidget(w)
        toolbar.addWidget(self._url_bar, 1)
        toolbar.addWidget(self._new_tab_btn)

        self._progress = QProgressBar(self)
        self._progress.setFixedHeight(3)
        self._progress.setTextVisible(False)
        self._progress.setStyleSheet(
            "QProgressBar { background: transparent; border: none; }"
            f"QProgressBar::chunk {{ background-color: {Theme.accent2.name()}; }}"
        )
        self._progress.hide()

        self._tabs = QTabWidget(self)
        self._tabs.setTabsClosable(True)
        self._tabs.setDocumentMode(True)
        self._tabs.tabCloseRequested.connect(self._close_tab)
        self._tabs.currentChanged.connect(self._on_current_tab_changed)
        self._tabs.setStyleSheet(
            "QTabWidget::pane { border: none; }"
            f"QTabBar::tab {{ background: {Theme.bg_surface.name()}; color: {Theme.text_muted.name()};"
            f" padding: 6px 14px; border-top-left-radius: 8px; border-top-right-radius: 8px; }}"
            f"QTabBar::tab:selected {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()}; }}"
        )

        layout.addLayout(toolbar)
        layout.addWidget(self._progress)
        layout.addWidget(self._tabs, 1)
        self.setLayout(layout)

        self._back_btn.clicked.connect(self._go_back)
        self._fwd_btn.clicked.connect(self._go_forward)
        self._reload_btn.clicked.connect(self._reload)
        self._home_btn.clicked.connect(lambda: self._navigate_current(HOME_URL))
        self._new_tab_btn.clicked.connect(lambda: self.open_new_tab(HOME_URL))

        self.open_new_tab(HOME_URL)

    def _nav_button(self, text: str) -> QToolButton:
        btn = QToolButton(self)
        btn.setText(text)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setFixedSize(34, 30)
        btn.setStyleSheet(
            f"QToolButton {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; font-size: 13pt; }}"
            f"QToolButton:hover {{ background: {Theme.border.name()}; }}"
            f"QToolButton:disabled {{ color: {Theme.text_muted.name()}; }}"
        )
        return btn

    def _current_view(self) -> Optional[BrowserTab]:
        return self._tabs.currentWidget()

    def open_new_tab(self, target: str = HOME_URL) -> BrowserTab:
        view = BrowserTab(self, self._tabs)
        view.urlChanged.connect(lambda url, v=view: self._on_url_changed(v, url))
        view.titleChanged.connect(lambda title, v=view: self._on_title_changed(v, title))
        view.loadProgress.connect(lambda p, v=view: self._on_load_progress(v, p))
        view.loadFinished.connect(lambda ok, v=view: self._on_load_finished(v, ok))

        index = self._tabs.addTab(view, "Новая вкладка")
        self._tabs.setCurrentIndex(index)
        self._navigate(view, target)
        return view

    def _close_tab(self, index: int):
        widget = self._tabs.widget(index)
        self._tabs.removeTab(index)
        if widget:
            widget.deleteLater()
        if self._tabs.count() == 0:
            self.open_new_tab(HOME_URL)

    def _on_current_tab_changed(self, index: int):
        view = self._tabs.widget(index)
        if view is None:
            return
        self._update_url_bar(view.url())
        self._update_nav_buttons(view)

    def _go_back(self):
        view = self._current_view()
        if view:
            view.back()

    def _go_forward(self):
        view = self._current_view()
        if view:
            view.forward()

    def _reload(self):
        view = self._current_view()
        if view:
            view.reload()

    def _navigate_to_bar_text(self):
        self._navigate_current(self._url_bar.text().strip())

    def _navigate_current(self, target: str):
        view = self._current_view()
        if view:
            self._navigate(view, target)

    def _navigate(self, view: BrowserTab, target: str):
        target = (target or "").strip()
        if not target or target == HOME_URL:
            view.last_target = HOME_URL
            view.setHtml(_home_html(), QUrl("about:blank"))
            return
        if "://" not in target:
            looks_like_domain = "." in target and " " not in target
            target = ("https://" + target) if looks_like_domain else SEARCH_URL_TEMPLATE.format(query=quote(target))
        view.last_target = target
        view.load(QUrl(target))

    def _on_url_changed(self, view: BrowserTab, url: QUrl):
        if view is self._current_view():
            self._update_url_bar(url)
            self._update_nav_buttons(view)

    def _update_url_bar(self, url: QUrl):
        text = url.toString()
        self._url_bar.setText("" if text in ("about:blank", "") else text)

    def _update_nav_buttons(self, view: BrowserTab):
        self._back_btn.setEnabled(view.history().canGoBack())
        self._fwd_btn.setEnabled(view.history().canGoForward())

    def _on_title_changed(self, view: BrowserTab, title: str):
        index = self._tabs.indexOf(view)
        if index < 0:
            return
        shown = title if title else "Новая вкладка"
        if len(shown) > 22:
            shown = shown[:21] + "…"
        self._tabs.setTabText(index, shown)

    def _on_load_progress(self, view: BrowserTab, progress: int):
        if view is self._current_view():
            self._progress.show()
            self._progress.setValue(progress)

    def _on_load_finished(self, view: BrowserTab, ok: bool):
        if view is self._current_view():
            self._progress.hide()
            self._update_nav_buttons(view)
        if not ok and view.last_target and view.last_target != HOME_URL:
            view.setHtml(_error_html(view.last_target), QUrl("about:blank"))


class BrowserApp(IApp):
    def id(self) -> str:
        return "browser"

    def name(self) -> str:
        return "Браузер"

    def icon_emoji(self) -> str:
        return "🌐"

    def description(self) -> str:
        return "Настоящий веб-браузер на движке Chromium — открывает реальные сайты по ссылкам."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        widget = BrowserWidget(parent)
        if context and context.get("url"):
            widget._navigate_current(context["url"])
        return widget

    def preferred_size(self) -> QSize:
        return QSize(1000, 700)
