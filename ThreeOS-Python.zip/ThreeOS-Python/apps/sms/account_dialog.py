"""
Диалог аккаунта ThreeOS: адрес сервера, регистрация и вход по номеру
телефона. См. services/account_service.py и server/threeos_server.py.
"""
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QFrame,
)

from core.theme import Theme
from services.account_service import AccountService


def _field(layout, placeholder: str, password: bool = False) -> QLineEdit:
    field = QLineEdit()
    field.setPlaceholderText(placeholder)
    if password:
        field.setEchoMode(QLineEdit.EchoMode.Password)
    field.setStyleSheet(
        f"QLineEdit {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
        f" border: none; border-radius: 8px; padding: 8px 12px; }}"
    )
    layout.addWidget(field)
    return field


def _button(text: str, primary: bool = False) -> QPushButton:
    btn = QPushButton(text)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    bg = Theme.accent.name() if primary else Theme.bg_surface_alt.name()
    fg = "white" if primary else Theme.text_primary.name()
    btn.setStyleSheet(
        f"QPushButton {{ background: {bg}; color: {fg}; border: none; border-radius: 8px; padding: 8px 16px; }}"
        f"QPushButton:hover {{ background: {Theme.accent_hover.name() if primary else Theme.border.name()}; }}"
    )
    return btn


class AccountDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._account = AccountService.instance()
        self.setWindowTitle("Аккаунт ThreeOS")
        self.resize(360, 460)
        self.setStyleSheet(f"background-color: {Theme.bg_surface.name()};")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)

        title = QLabel("Аккаунт")
        title.setFont(QFont(Theme.font_display, 16, QFont.Weight.DemiBold))
        title.setStyleSheet(f"color: {Theme.text_primary.name()};")
        layout.addWidget(title)

        self._status_label = QLabel()
        self._status_label.setWordWrap(True)
        self._status_label.setFont(QFont(Theme.font_ui, 9))
        layout.addWidget(self._status_label)

        # --- сервер ---
        server_caption = QLabel("СЕРВЕР")
        server_caption.setFont(QFont(Theme.font_ui, 8, QFont.Weight.DemiBold))
        server_caption.setStyleSheet(f"color: {Theme.text_muted.name()}; letter-spacing: 1px; margin-top: 6px;")
        layout.addWidget(server_caption)

        host, port = self._account.server_address()
        server_row = QHBoxLayout()
        self._host_field = QLineEdit(host)
        self._host_field.setStyleSheet(
            f"QLineEdit {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 8px 12px; }}"
        )
        self._port_field = QLineEdit(str(port))
        self._port_field.setFixedWidth(70)
        self._port_field.setStyleSheet(self._host_field.styleSheet())
        server_row.addWidget(self._host_field, 1)
        server_row.addWidget(self._port_field)
        layout.addLayout(server_row)
        save_server_btn = _button("Сохранить адрес сервера")
        save_server_btn.clicked.connect(self._save_server)
        layout.addWidget(save_server_btn)

        divider = QFrame()
        divider.setFrameShape(QFrame.Shape.HLine)
        divider.setStyleSheet(f"background-color: {Theme.border.name()}; max-height: 1px; margin: 8px 0;")
        layout.addWidget(divider)

        # --- вход/регистрация ---
        auth_caption = QLabel("НОМЕР ТЕЛЕФОНА И ПАРОЛЬ")
        auth_caption.setFont(QFont(Theme.font_ui, 8, QFont.Weight.DemiBold))
        auth_caption.setStyleSheet(f"color: {Theme.text_muted.name()}; letter-spacing: 1px;")
        layout.addWidget(auth_caption)

        self._phone_field = _field(layout, "+7 700 000 0000")
        self._password_field = _field(layout, "Пароль", password=True)
        self._name_field = _field(layout, "Имя (только для регистрации)")

        btn_row = QHBoxLayout()
        login_btn = _button("Войти", primary=True)
        register_btn = _button("Зарегистрироваться")
        btn_row.addWidget(login_btn)
        btn_row.addWidget(register_btn)
        layout.addLayout(btn_row)

        logout_btn = _button("Выйти из аккаунта")
        layout.addWidget(logout_btn)

        layout.addStretch()

        login_btn.clicked.connect(self._do_login)
        register_btn.clicked.connect(self._do_register)
        logout_btn.clicked.connect(self._do_logout)

        self._account.login_result.connect(self._on_login_result)
        self._account.register_result.connect(self._on_register_result)

        self._update_status()

    def _save_server(self):
        try:
            port = int(self._port_field.text().strip())
        except ValueError:
            self._status_label.setText("Порт должен быть числом")
            self._status_label.setStyleSheet(f"color: {Theme.danger.name()};")
            return
        self._account.set_server_address(self._host_field.text().strip(), port)
        self._status_label.setText("Адрес сервера сохранён")
        self._status_label.setStyleSheet(f"color: {Theme.accent2.name()};")

    def _do_login(self):
        phone, password = self._phone_field.text().strip(), self._password_field.text()
        if not phone or not password:
            self._status_label.setText("Укажите номер и пароль")
            self._status_label.setStyleSheet(f"color: {Theme.danger.name()};")
            return
        self._status_label.setText("Подключение…")
        self._status_label.setStyleSheet(f"color: {Theme.text_muted.name()};")
        self._account.login(phone, password)

    def _do_register(self):
        phone, password = self._phone_field.text().strip(), self._password_field.text()
        name = self._name_field.text().strip() or phone
        if not phone or not password:
            self._status_label.setText("Укажите номер и пароль")
            self._status_label.setStyleSheet(f"color: {Theme.danger.name()};")
            return
        self._status_label.setText("Регистрация…")
        self._status_label.setStyleSheet(f"color: {Theme.text_muted.name()};")
        self._account.register(phone, password, name)

    def _do_logout(self):
        self._account.logout()
        self._update_status()

    def _on_login_result(self, ok: bool, reason: str):
        if ok:
            self._status_label.setText(f"Вы вошли как {self._account.phone}")
            self._status_label.setStyleSheet(f"color: {Theme.accent2.name()};")
        else:
            self._status_label.setText(f"Не удалось войти: {reason}")
            self._status_label.setStyleSheet(f"color: {Theme.danger.name()};")

    def _on_register_result(self, ok: bool, reason: str):
        if ok:
            self._status_label.setText("Аккаунт создан! Теперь войдите.")
            self._status_label.setStyleSheet(f"color: {Theme.accent2.name()};")
        else:
            self._status_label.setText(f"Не удалось зарегистрироваться: {reason}")
            self._status_label.setStyleSheet(f"color: {Theme.danger.name()};")

    def _update_status(self):
        if self._account.logged_in:
            self._status_label.setText(f"Вы вошли как {self._account.phone}")
            self._status_label.setStyleSheet(f"color: {Theme.accent2.name()};")
        else:
            self._status_label.setText("Вы не вошли в аккаунт — сообщения по номеру не будут доставляться.")
            self._status_label.setStyleSheet(f"color: {Theme.text_muted.name()};")
