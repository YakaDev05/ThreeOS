"""
СМС ThreeOS: список диалогов слева (по контактам), переписка справа.

Два способа доставки, оба настоящие:
  1. Через AccountService (services/account_service.py) — по номеру
     телефона через сервер (server/threeos_server.py). Работает через
     интернет между любыми сетями, если вы вошли в аккаунт и у контакта
     есть номер. Приоритетный способ, если вы залогинены.
  2. Через NetworkService (LAN, без сервера) — если контакт привязан к
     обнаруженному в локальной сети ThreeOS (device_id).

Никакого автоответчика: если в диалоге появляется ответ, значит его
напечатал реальный человек. Если доставить некому (не в сети, нет
аккаунта, контакт без привязки вообще) — сообщение честно помечается
как недоставленное или поставленное в очередь, без иллюзий.
"""
from typing import Optional

from PySide6.QtCore import Qt, QSize, QTimer
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QListWidget, QListWidgetItem,
    QLabel, QLineEdit, QPushButton, QScrollArea, QSplitter, QInputDialog,
)

from core.iapp import IApp
from core.theme import Theme
from services.contacts_store import ContactsStore
from services.messages_store import MessagesStore
from services.network_service import NetworkService
from services.account_service import AccountService
from services.identity import Identity
from apps.sms.account_dialog import AccountDialog


class MessageBubble(QWidget):
    def __init__(self, text: str, outgoing: bool, delivered: bool, queued: bool, pending: bool, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        bubble = QLabel(text)
        bubble.setWordWrap(True)
        bubble.setFont(QFont(Theme.font_ui, 10))
        bubble.setMaximumWidth(360)
        bg = Theme.accent.name() if outgoing else Theme.bg_surface_alt.name()
        fg = "white" if outgoing else Theme.text_primary.name()
        bubble.setStyleSheet(f"background-color: {bg}; color: {fg}; border-radius: 12px; padding: 8px 12px;")
        layout.addWidget(bubble, 0, Qt.AlignmentFlag.AlignRight if outgoing else Qt.AlignmentFlag.AlignLeft)

        if outgoing:
            if pending:
                status_text, color = "отправка…", Theme.text_muted.name()
            elif queued:
                status_text, color = "в очереди — доставится, когда собеседник зайдёт", Theme.text_muted.name()
            elif not delivered:
                status_text, color = "не доставлено", Theme.danger.name()
            else:
                status_text, color = None, None
            if status_text:
                status = QLabel(status_text)
                status.setFont(QFont(Theme.font_ui, 8))
                status.setStyleSheet(f"color: {color};")
                layout.addWidget(status, 0, Qt.AlignmentFlag.AlignRight)


class SmsWidget(QWidget):
    def __init__(self, parent=None, initial_contact_id: Optional[str] = None):
        super().__init__(parent)
        self._contacts = ContactsStore.instance()
        self._messages = MessagesStore.instance()
        self._network = NetworkService.instance()
        self._account = AccountService.instance()
        self._identity = Identity.instance()
        self._current_contact_id: Optional[str] = None
        self._pending_sends: dict = {}  # client_msg_id -> (contact_id, message_id)

        self.setStyleSheet(f"background-color: {Theme.bg_surface.name()};")

        splitter = QSplitter(self)
        splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {Theme.border.name()}; }}")
        splitter.addWidget(self._build_list_panel())
        splitter.addWidget(self._build_thread_panel())
        splitter.setSizes([250, 420])

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(splitter)
        self.setLayout(outer)

        self._contacts.contacts_changed.connect(self._refresh_conversations)
        self._messages.messages_changed.connect(self._on_messages_changed)
        self._network.peers_changed.connect(self._on_peers_changed)
        self._account.send_result.connect(self._on_send_result)
        self._refresh_conversations()

        if initial_contact_id and self._contacts.get(initial_contact_id):
            self._select_conversation(initial_contact_id)

    # ---------- построение панелей ----------
    def _build_list_panel(self) -> QWidget:
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(10, 10, 6, 10)
        left_layout.setSpacing(6)

        title = QLabel("Сообщения")
        title.setFont(QFont(Theme.font_display, 15, QFont.Weight.DemiBold))
        title.setStyleSheet(f"color: {Theme.text_primary.name()};")
        left_layout.addWidget(title)

        self._me_label = QPushButton()
        self._me_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self._me_label.setFlat(True)
        self._me_label.setFont(QFont(Theme.font_ui, 9))
        self._me_label.setStyleSheet(f"QPushButton {{ color: {Theme.text_muted.name()}; text-align: left; border: none; }}")
        self._update_me_label()
        self._me_label.clicked.connect(self._change_display_name)
        left_layout.addWidget(self._me_label)

        self._account_btn = QPushButton()
        self._account_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._account_btn.setFlat(True)
        self._account_btn.setFont(QFont(Theme.font_ui, 9))
        self._account_btn.setStyleSheet(f"QPushButton {{ color: {Theme.text_muted.name()}; text-align: left; border: none; }}")
        self._update_account_label()
        self._account_btn.clicked.connect(self._open_account_dialog)
        left_layout.addWidget(self._account_btn)

        self._list = QListWidget()
        self._list.setStyleSheet(
            "QListWidget { background: transparent; border: none; }"
            "QListWidget::item { padding: 10px 8px; border-radius: 8px; }"
            f"QListWidget::item:selected {{ background: {Theme.bg_surface_alt.name()}; }}"
        )
        self._list.itemClicked.connect(self._on_conversation_clicked)
        left_layout.addWidget(self._list, 1)
        return left

    def _build_thread_panel(self) -> QWidget:
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        self._thread_header = QLabel("Выберите диалог")
        self._thread_header.setFont(QFont(Theme.font_ui, 11, QFont.Weight.DemiBold))
        self._thread_header.setStyleSheet(
            f"color: {Theme.text_primary.name()}; padding: 14px; border-bottom: 1px solid {Theme.border.name()};"
        )
        right_layout.addWidget(self._thread_header)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setStyleSheet("border: none;")
        self._thread_container = QWidget()
        self._thread_layout = QVBoxLayout(self._thread_container)
        self._thread_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._thread_layout.setContentsMargins(14, 14, 14, 14)
        self._thread_layout.setSpacing(8)
        self._scroll.setWidget(self._thread_container)
        right_layout.addWidget(self._scroll, 1)

        input_row = QHBoxLayout()
        input_row.setContentsMargins(12, 10, 12, 12)
        self._input = QLineEdit()
        self._input.setPlaceholderText("Напишите сообщение…")
        self._input.setStyleSheet(
            f"QLineEdit {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 18px; padding: 10px 16px; }}"
        )
        self._input.returnPressed.connect(self._send_message)
        send_btn = QPushButton("➤")
        send_btn.setFixedSize(36, 36)
        send_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        send_btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.accent.name()}; color: white; border: none; border-radius: 18px; }}"
            f"QPushButton:hover {{ background: {Theme.accent_hover.name()}; }}"
        )
        send_btn.clicked.connect(self._send_message)
        input_row.addWidget(self._input, 1)
        input_row.addWidget(send_btn)
        right_layout.addLayout(input_row)
        return right

    # ---------- собственное имя и аккаунт ----------
    def _update_me_label(self):
        self._me_label.setText(f"Вы в сети: {self._identity.display_name}  ✎")

    def _change_display_name(self):
        name, ok = QInputDialog.getText(self, "Ваше имя в локальной сети", "Под этим именем вас увидят другие в локальной сети:",
                                         text=self._identity.display_name)
        if ok and name.strip():
            self._identity.set_display_name(name.strip())
            self._update_me_label()

    def _update_account_label(self):
        if self._account.logged_in:
            self._account_btn.setText(f"⚙ Аккаунт: {self._account.phone}")
        else:
            self._account_btn.setText("⚙ Аккаунт: не выполнен вход")

    def _open_account_dialog(self):
        dialog = AccountDialog(self)
        dialog.exec()
        self._update_account_label()
        self._refresh_conversations()

    # ---------- логика списка диалогов ----------
    def _refresh_conversations(self):
        self._list.clear()
        contacts = self._contacts.all()

        def sort_key(c):
            last = self._messages.last_message(c.id)
            return last.timestamp if last else ""

        contacts.sort(key=sort_key, reverse=True)

        for contact in contacts:
            last = self._messages.last_message(contact.id)
            preview = last.text if last else "Нет сообщений"
            if len(preview) > 34:
                preview = preview[:33] + "…"
            online = bool(contact.device_id) and self._network.is_online(contact.device_id)
            dot = "🟢 " if online else ("⚪ " if contact.device_id else "")
            item = QListWidgetItem(f"{dot}{contact.name}\n{preview}")
            item.setData(Qt.ItemDataRole.UserRole, contact.id)
            item.setFont(QFont(Theme.font_ui, 10))
            self._list.addItem(item)
            if contact.id == self._current_contact_id:
                item.setSelected(True)

    def _on_conversation_clicked(self, item: QListWidgetItem):
        self._select_conversation(item.data(Qt.ItemDataRole.UserRole))

    def _select_conversation(self, contact_id: str):
        contact = self._contacts.get(contact_id)
        if contact is None:
            return
        self._current_contact_id = contact_id
        self._update_thread_header(contact)
        self._render_thread()

    def _update_thread_header(self, contact):
        if not contact.device_id:
            status = "нет сетевой привязки"
        elif self._network.is_online(contact.device_id):
            status = "в сети"
        else:
            status = "не в сети"
        self._thread_header.setText(f"{contact.name}   ·   {status}")

    def _render_thread(self):
        while self._thread_layout.count():
            child = self._thread_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        if not self._current_contact_id:
            return

        for msg in self._messages.thread(self._current_contact_id):
            row = QHBoxLayout()
            bubble = MessageBubble(msg.text, msg.outgoing, msg.delivered, msg.queued, msg.pending)
            if msg.outgoing:
                row.addStretch()
                row.addWidget(bubble)
            else:
                row.addWidget(bubble)
                row.addStretch()
            self._thread_layout.addLayout(row)

        QTimer.singleShot(0, self._scroll_to_bottom)

    def _scroll_to_bottom(self):
        bar = self._scroll.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _on_messages_changed(self, contact_id: str):
        if contact_id == self._current_contact_id:
            self._render_thread()
        self._refresh_conversations()

    def _on_peers_changed(self):
        self._refresh_conversations()
        if self._current_contact_id:
            contact = self._contacts.get(self._current_contact_id)
            if contact:
                self._update_thread_header(contact)

    # ---------- отправка ----------
    def _send_message(self):
        text = self._input.text().strip()
        if not text or not self._current_contact_id:
            return
        contact = self._contacts.get(self._current_contact_id)
        if contact is None:
            return
        self._input.clear()

        # Приоритет 1: аккаунт-сервер по номеру телефона (работает через
        # интернет, между любыми сетями) — если мы вошли и у контакта есть
        # номер, результат придёт асинхронно через send_result.
        if self._account.logged_in and contact.phone:
            msg = self._messages.send(contact.id, text, delivered=False, pending=True)
            client_msg_id = self._account.send_message(contact.phone, text)
            self._pending_sends[client_msg_id] = (contact.id, msg.id)
            return

        # Приоритет 2: локальная сеть напрямую (без сервера), если контакт
        # обнаружен через NetworkService.
        delivered = bool(contact.device_id) and self._network.send_message(contact.device_id, text)
        self._messages.send(contact.id, text, delivered=delivered)

    def _on_send_result(self, client_msg_id: str, ok: bool, queued: bool):
        pending = self._pending_sends.pop(client_msg_id, None)
        if pending is None:
            return
        contact_id, message_id = pending
        self._messages.update_status(contact_id, message_id, delivered=ok and not queued, queued=ok and queued)


class SmsApp(IApp):
    def id(self) -> str:
        return "sms"

    def name(self) -> str:
        return "СМС"

    def icon_emoji(self) -> str:
        return "💬"

    def description(self) -> str:
        return "Переписка по номеру телефона (через аккаунт) или напрямую в локальной сети."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        initial_id = context.get("contact_id") if context else None
        return SmsWidget(parent, initial_contact_id=initial_id)

    def preferred_size(self) -> QSize:
        return QSize(700, 560)
