"""
Настройки ThreeOS: информация о системе, сетевое имя (LAN) и быстрый
доступ к аккаунту. Не дублирует логику — использует те же сервисы, что
СМС (Identity, AccountService), просто даёт им один общий дом.
"""
from typing import Optional

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QFrame,
)

from core.iapp import IApp
from core.theme import Theme
from services.identity import Identity
from services.account_service import AccountService
from apps.sms.account_dialog import AccountDialog


def _section_caption(text: str) -> QLabel:
    lbl = QLabel(text.upper())
    lbl.setFont(QFont(Theme.font_ui, 8, QFont.Weight.DemiBold))
    lbl.setStyleSheet(f"color: {Theme.text_muted.name()}; letter-spacing: 1px; margin-top: 10px;")
    return lbl


class SettingsWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._identity = Identity.instance()
        self._account = AccountService.instance()

        self.setStyleSheet(f"background-color: {Theme.bg_surface.name()};")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        title = QLabel("⚙ Настройки")
        title.setFont(QFont(Theme.font_display, 18, QFont.Weight.DemiBold))
        title.setStyleSheet(f"color: {Theme.text_primary.name()};")
        layout.addWidget(title)

        # --- о системе ---
        layout.addWidget(_section_caption("О системе"))
        about = QLabel("ThreeOS версия 1.0\nАвтор: Said (Yaka) Hamidov\nОболочка: Python 3 / PySide6")
        about.setFont(QFont(Theme.font_ui, 10))
        about.setStyleSheet(f"color: {Theme.text_primary.name()};")
        layout.addWidget(about)

        # --- локальная сеть ---
        layout.addWidget(_section_caption("Имя в локальной сети (LAN)"))
        lan_row = QHBoxLayout()
        self._name_field = QLineEdit(self._identity.display_name)
        self._name_field.setStyleSheet(
            f"QLineEdit {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 8px 12px; }}"
        )
        save_name_btn = QPushButton("Сохранить")
        save_name_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        save_name_btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.accent.name()}; color: white; border: none;"
            f" border-radius: 8px; padding: 8px 16px; }}"
            f"QPushButton:hover {{ background: {Theme.accent_hover.name()}; }}"
        )
        save_name_btn.clicked.connect(self._save_name)
        lan_row.addWidget(self._name_field, 1)
        lan_row.addWidget(save_name_btn)
        layout.addLayout(lan_row)
        hint = QLabel("Под этим именем вас видят другие ThreeOS в этой же Wi-Fi/локальной сети.")
        hint.setWordWrap(True)
        hint.setFont(QFont(Theme.font_ui, 8))
        hint.setStyleSheet(f"color: {Theme.text_muted.name()};")
        layout.addWidget(hint)

        # --- аккаунт ---
        layout.addWidget(_section_caption("Аккаунт (доставка по номеру телефона)"))
        self._account_status = QLabel()
        self._account_status.setFont(QFont(Theme.font_ui, 10))
        self._update_account_status()
        layout.addWidget(self._account_status)

        account_btn = QPushButton("Открыть настройки аккаунта")
        account_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        account_btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 8px 16px; }}"
            f"QPushButton:hover {{ background: {Theme.border.name()}; }}"
        )
        account_btn.clicked.connect(self._open_account_dialog)
        layout.addWidget(account_btn)

        layout.addStretch()

    def _save_name(self):
        name = self._name_field.text().strip()
        if name:
            self._identity.set_display_name(name)

    def _update_account_status(self):
        if self._account.logged_in:
            self._account_status.setText(f"Вы вошли как {self._account.phone}")
            self._account_status.setStyleSheet(f"color: {Theme.accent2.name()};")
        else:
            self._account_status.setText("Вход не выполнен")
            self._account_status.setStyleSheet(f"color: {Theme.text_muted.name()};")

    def _open_account_dialog(self):
        dialog = AccountDialog(self)
        dialog.exec()
        self._update_account_status()


class SettingsApp(IApp):
    def id(self) -> str:
        return "settings"

    def name(self) -> str:
        return "Настройки"

    def icon_emoji(self) -> str:
        return "⚙️"

    def description(self) -> str:
        return "Имя в локальной сети, аккаунт и информация о системе."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        return SettingsWidget(parent)

    def preferred_size(self) -> QSize:
        return QSize(460, 520)
