"""
Заметки ThreeOS: список заметок слева, редактор справа. Сохраняется
автоматически (с небольшой задержкой после последней правки) — отдельная
кнопка "Сохранить" не нужна.
"""
from typing import Optional

from PySide6.QtCore import Qt, QSize, QTimer
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QListWidget, QListWidgetItem,
    QLabel, QLineEdit, QTextEdit, QPushButton, QSplitter, QMessageBox,
)

from core.iapp import IApp
from core.theme import Theme
from services.notes_store import NotesStore


class NotesWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._store = NotesStore.instance()
        self._current_id: Optional[str] = None

        self.setStyleSheet(f"background-color: {Theme.bg_surface.name()};")

        splitter = QSplitter(self)
        splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {Theme.border.name()}; }}")
        splitter.addWidget(self._build_list_panel())
        splitter.addWidget(self._build_editor_panel())
        splitter.setSizes([220, 420])

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(splitter)
        self.setLayout(outer)

        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self._save_current)

        self._store.notes_changed.connect(self._refresh_list)
        self._refresh_list()

    def _build_list_panel(self) -> QWidget:
        left = QWidget()
        layout = QVBoxLayout(left)
        layout.setContentsMargins(10, 10, 6, 10)
        layout.setSpacing(8)

        header = QHBoxLayout()
        title = QLabel("Заметки")
        title.setFont(QFont(Theme.font_display, 15, QFont.Weight.DemiBold))
        title.setStyleSheet(f"color: {Theme.text_primary.name()};")
        add_btn = QPushButton("+")
        add_btn.setFixedSize(30, 30)
        add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        add_btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.accent.name()}; color: white; border: none;"
            f" border-radius: 15px; font-size: 14pt; }}"
            f"QPushButton:hover {{ background: {Theme.accent_hover.name()}; }}"
        )
        add_btn.clicked.connect(self._create_note)
        header.addWidget(title)
        header.addStretch()
        header.addWidget(add_btn)
        layout.addLayout(header)

        self._list = QListWidget()
        self._list.setStyleSheet(
            "QListWidget { background: transparent; border: none; }"
            "QListWidget::item { padding: 8px; border-radius: 8px; }"
            f"QListWidget::item:selected {{ background: {Theme.bg_surface_alt.name()}; }}"
        )
        self._list.itemClicked.connect(self._on_item_clicked)
        layout.addWidget(self._list, 1)
        return left

    def _build_editor_panel(self) -> QWidget:
        right = QWidget()
        layout = QVBoxLayout(right)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(8)

        top_row = QHBoxLayout()
        self._title_field = QLineEdit()
        self._title_field.setPlaceholderText("Заголовок")
        self._title_field.setFont(QFont(Theme.font_display, 13, QFont.Weight.DemiBold))
        self._title_field.setStyleSheet(
            f"QLineEdit {{ background: transparent; color: {Theme.text_primary.name()}; border: none; }}"
        )
        self._title_field.textChanged.connect(self._schedule_save)
        delete_btn = QPushButton("🗑")
        delete_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        delete_btn.setFixedSize(32, 32)
        delete_btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; }}"
            f"QPushButton:hover {{ background: {Theme.border.name()}; }}"
        )
        delete_btn.clicked.connect(self._delete_current)
        top_row.addWidget(self._title_field, 1)
        top_row.addWidget(delete_btn)
        layout.addLayout(top_row)

        self._body_field = QTextEdit()
        self._body_field.setFont(QFont(Theme.font_ui, 11))
        self._body_field.setStyleSheet(
            f"QTextEdit {{ background: {Theme.bg_base.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 10px; }}"
        )
        self._body_field.textChanged.connect(self._schedule_save)
        layout.addWidget(self._body_field, 1)

        self._empty_hint = QLabel("Выберите заметку слева или создайте новую")
        self._empty_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._empty_hint.setStyleSheet(f"color: {Theme.text_muted.name()};")
        layout.addWidget(self._empty_hint)

        self._set_editor_enabled(False)
        return right

    def _set_editor_enabled(self, enabled: bool):
        self._title_field.setVisible(enabled)
        self._body_field.setVisible(enabled)
        self._empty_hint.setVisible(not enabled)

    def _refresh_list(self):
        self._list.clear()
        for note in self._store.all():
            preview = note.title or "Без названия"
            item = QListWidgetItem(preview)
            item.setData(Qt.ItemDataRole.UserRole, note.id)
            item.setFont(QFont(Theme.font_ui, 10))
            self._list.addItem(item)
            if note.id == self._current_id:
                item.setSelected(True)

    def _on_item_clicked(self, item: QListWidgetItem):
        self._open_note(item.data(Qt.ItemDataRole.UserRole))

    def _open_note(self, note_id: str):
        note = self._store.get(note_id)
        if note is None:
            return
        self._current_id = note_id
        self._title_field.blockSignals(True)
        self._body_field.blockSignals(True)
        self._title_field.setText(note.title)
        self._body_field.setPlainText(note.body)
        self._title_field.blockSignals(False)
        self._body_field.blockSignals(False)
        self._set_editor_enabled(True)

    def _create_note(self):
        note = self._store.create()
        self._open_note(note.id)

    def _schedule_save(self):
        if self._current_id:
            self._save_timer.start(500)

    def _save_current(self):
        if not self._current_id:
            return
        self._store.update(self._current_id, title=self._title_field.text(), body=self._body_field.toPlainText())

    def _delete_current(self):
        if not self._current_id:
            return
        confirm = QMessageBox(self)
        confirm.setWindowTitle("Удалить заметку")
        confirm.setText("Удалить эту заметку без возможности восстановления?")
        confirm.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel)
        confirm.setDefaultButton(QMessageBox.StandardButton.Cancel)
        if confirm.exec() == QMessageBox.StandardButton.Yes:
            self._store.remove(self._current_id)
            self._current_id = None
            self._set_editor_enabled(False)


class NotesApp(IApp):
    def id(self) -> str:
        return "notes"

    def name(self) -> str:
        return "Заметки"

    def icon_emoji(self) -> str:
        return "📝"

    def description(self) -> str:
        return "Быстрые заметки с автосохранением."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        return NotesWidget(parent)

    def preferred_size(self) -> QSize:
        return QSize(560, 460)

    def is_core(self) -> bool:
        return False
