"""
Контакты ThreeOS: список контактов слева, подробности/редактирование справа.

Наверху списка — "Люди в сети": те, кто прямо сейчас запустил ThreeOS в той
же локальной сети (обнаруживаются через services/network_service.py).
Их можно добавить в контакты одним нажатием — после этого с ними можно
по-настоящему переписываться в СМС. Обычные контакты (без сетевой
привязки, например демо-контакт "Мама") остаются в адресной книге, но
сообщения им доставить некому — это просто карточка с телефоном/заметкой.
"""
from typing import Dict, Optional

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QListWidget, QListWidgetItem,
    QLabel, QLineEdit, QPushButton, QStackedWidget, QSplitter, QMessageBox,
)

from core.iapp import IApp
from core.theme import Theme
from services.contacts_store import ContactsStore, Contact
from services.network_service import NetworkService
from services.app_bus import AppBus


class ContactsWidget(QWidget):
    def __init__(self, parent=None, initial_contact_id: Optional[str] = None):
        super().__init__(parent)
        self._store = ContactsStore.instance()
        self._network = NetworkService.instance()
        self._current_id: Optional[str] = None

        self.setStyleSheet(f"background-color: {Theme.bg_surface.name()};")

        splitter = QSplitter(self)
        splitter.setStyleSheet(f"QSplitter::handle {{ background-color: {Theme.border.name()}; }}")

        splitter.addWidget(self._build_list_panel())

        self._right_stack = QStackedWidget()
        self._empty_page = self._build_empty_page()
        self._detail_page, self._detail_widgets = self._build_detail_page()
        self._edit_page, self._edit_widgets = self._build_edit_page()
        self._right_stack.addWidget(self._empty_page)
        self._right_stack.addWidget(self._detail_page)
        self._right_stack.addWidget(self._edit_page)
        splitter.addWidget(self._right_stack)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([260, 400])

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(splitter)
        self.setLayout(outer)

        self._store.contacts_changed.connect(self._refresh_all)
        self._network.peers_changed.connect(self._refresh_all)
        self._refresh_all()

        if initial_contact_id and self._store.get(initial_contact_id):
            self._select_contact(initial_contact_id)

    # ---------- построение панелей ----------
    def _build_list_panel(self) -> QWidget:
        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(10, 10, 6, 10)
        left_layout.setSpacing(8)

        header_row = QHBoxLayout()
        title = QLabel("Контакты")
        title.setFont(QFont(Theme.font_display, 15, QFont.Weight.DemiBold))
        title.setStyleSheet(f"color: {Theme.text_primary.name()};")
        add_btn = QPushButton("+")
        add_btn.setFixedSize(30, 30)
        add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        add_btn.setStyleSheet(
            f"QPushButton {{ background: {Theme.accent.name()}; color: white; border: none;"
            f" border-radius: 15px; font-size: 14pt; }}"
            f"QPushButton:hover {{ background: {Theme.accent_hover.name()}; }}"
        )
        add_btn.clicked.connect(self._start_new_contact)
        header_row.addWidget(title)
        header_row.addStretch()
        header_row.addWidget(add_btn)
        left_layout.addLayout(header_row)

        # --- люди в сети прямо сейчас, ещё не добавленные в контакты ---
        self._network_caption = QLabel("🟢 ЛЮДИ В СЕТИ")
        self._network_caption.setFont(QFont(Theme.font_ui, 8, QFont.Weight.DemiBold))
        self._network_caption.setStyleSheet(f"color: {Theme.text_muted.name()}; letter-spacing: 1px; margin-top: 4px;")
        self._network_container = QWidget()
        self._network_layout = QVBoxLayout(self._network_container)
        self._network_layout.setContentsMargins(0, 0, 0, 0)
        self._network_layout.setSpacing(4)
        left_layout.addWidget(self._network_caption)
        left_layout.addWidget(self._network_container)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Поиск…")
        self._search.setStyleSheet(
            f"QLineEdit {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 8px 12px; }}"
        )
        self._search.textChanged.connect(self._refresh_contact_list)
        left_layout.addWidget(self._search)

        self._list = QListWidget()
        self._list.setStyleSheet(
            "QListWidget { background: transparent; border: none; }"
            "QListWidget::item { padding: 8px; border-radius: 8px; }"
            f"QListWidget::item:selected {{ background: {Theme.bg_surface_alt.name()}; }}"
        )
        self._list.itemClicked.connect(self._on_list_item_clicked)
        left_layout.addWidget(self._list, 1)
        return left

    def _build_empty_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl = QLabel("Выберите контакт\nили добавьте новый")
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl.setStyleSheet(f"color: {Theme.text_muted.name()}; font-size: 12pt;")
        layout.addWidget(lbl)
        return page

    def _build_detail_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(4)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        avatar_row = QHBoxLayout()
        avatar_lbl = QLabel()
        avatar_lbl.setFixedSize(64, 64)
        avatar_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        avatar_lbl.setFont(QFont(Theme.font_ui, 22, QFont.Weight.DemiBold))
        name_lbl = QLabel()
        name_lbl.setFont(QFont(Theme.font_display, 20, QFont.Weight.DemiBold))
        name_lbl.setStyleSheet(f"color: {Theme.text_primary.name()};")
        avatar_row.addWidget(avatar_lbl)
        avatar_row.addSpacing(14)
        avatar_row.addWidget(name_lbl)
        avatar_row.addStretch()
        layout.addLayout(avatar_row)
        layout.addSpacing(18)

        network_lbl = self._info_row(layout, "Статус сети")
        phone_lbl = self._info_row(layout, "Телефон")
        email_lbl = self._info_row(layout, "Email")
        note_lbl = self._info_row(layout, "Заметка")

        layout.addSpacing(16)
        btn_row = QHBoxLayout()
        msg_btn = self._pill_button("💬  Написать", Theme.accent2.name(), "#04302a")
        edit_btn = self._pill_button("✎  Изменить", Theme.bg_surface_alt.name(), Theme.text_primary.name())
        del_btn = self._pill_button("🗑  Удалить", Theme.bg_surface_alt.name(), Theme.text_primary.name())
        btn_row.addWidget(msg_btn)
        btn_row.addWidget(edit_btn)
        btn_row.addWidget(del_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        msg_btn.clicked.connect(self._open_in_sms)
        edit_btn.clicked.connect(self._start_edit)
        del_btn.clicked.connect(self._delete_current)

        widgets = {
            "avatar": avatar_lbl, "name": name_lbl, "network": network_lbl,
            "phone": phone_lbl, "email": email_lbl, "note": note_lbl,
        }
        return page, widgets

    def _pill_button(self, text: str, bg: str, fg: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setStyleSheet(
            f"QPushButton {{ background: {bg}; color: {fg}; border: none; border-radius: 8px; padding: 8px 16px; }}"
            f"QPushButton:hover {{ background: {Theme.border.name()}; }}"
        )
        return btn

    def _info_row(self, layout: QVBoxLayout, label_text: str) -> QLabel:
        row = QVBoxLayout()
        caption = QLabel(label_text.upper())
        caption.setFont(QFont(Theme.font_ui, 8, QFont.Weight.DemiBold))
        caption.setStyleSheet(f"color: {Theme.text_muted.name()}; letter-spacing: 1px;")
        value = QLabel("—")
        value.setFont(QFont(Theme.font_ui, 11))
        value.setStyleSheet(f"color: {Theme.text_primary.name()};")
        row.addWidget(caption)
        row.addWidget(value)
        row.addSpacing(8)
        layout.addLayout(row)
        return value

    def _build_edit_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(10)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        title = QLabel("Контакт")
        title.setFont(QFont(Theme.font_display, 16, QFont.Weight.DemiBold))
        title.setStyleSheet(f"color: {Theme.text_primary.name()};")
        layout.addWidget(title)

        name_edit = self._form_field(layout, "Имя")
        phone_edit = self._form_field(layout, "Телефон")
        email_edit = self._form_field(layout, "Email")
        note_edit = self._form_field(layout, "Заметка")

        layout.addSpacing(14)
        btn_row = QHBoxLayout()
        save_btn = self._pill_button("Сохранить", Theme.accent.name(), "white")
        cancel_btn = self._pill_button("Отмена", Theme.bg_surface_alt.name(), Theme.text_primary.name())
        btn_row.addWidget(save_btn)
        btn_row.addWidget(cancel_btn)
        btn_row.addStretch()
        layout.addLayout(btn_row)

        save_btn.clicked.connect(self._save_edit)
        cancel_btn.clicked.connect(self._cancel_edit)

        widgets: Dict[str, QLineEdit] = {"name": name_edit, "phone": phone_edit, "email": email_edit, "note": note_edit}
        return page, widgets

    def _form_field(self, layout: QVBoxLayout, label_text: str) -> QLineEdit:
        caption = QLabel(label_text)
        caption.setFont(QFont(Theme.font_ui, 9, QFont.Weight.DemiBold))
        caption.setStyleSheet(f"color: {Theme.text_muted.name()};")
        field = QLineEdit()
        field.setStyleSheet(
            f"QLineEdit {{ background: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 8px; padding: 8px 12px; }}"
        )
        layout.addWidget(caption)
        layout.addWidget(field)
        return field

    # ---------- обновление данных ----------
    def _refresh_all(self):
        self._refresh_network_section()
        self._refresh_contact_list()
        if self._current_id:
            contact = self._store.get(self._current_id)
            if contact and self._right_stack.currentWidget() is self._detail_page:
                self._select_contact(self._current_id)

    def _refresh_network_section(self):
        while self._network_layout.count():
            child = self._network_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        peers = self._network.peers()
        new_peers = [p for p in peers.values() if self._store.find_by_device_id(p.device_id) is None]

        if not new_peers:
            self._network_caption.hide()
            self._network_container.hide()
            return

        self._network_caption.show()
        self._network_container.show()
        for peer in new_peers:
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            lbl = QLabel(f"🟢 {peer.name}")
            lbl.setFont(QFont(Theme.font_ui, 10))
            lbl.setStyleSheet(f"color: {Theme.text_primary.name()};")
            add_btn = QPushButton("+ Добавить")
            add_btn.setCursor(Qt.CursorShape.PointingHandCursor)
            add_btn.setStyleSheet(
                f"QPushButton {{ background: {Theme.accent2.name()}; color: #04302a; border: none;"
                f" border-radius: 6px; padding: 4px 10px; font-size: 9pt; }}"
                f"QPushButton:hover {{ background: {Theme.accent2.name()}; }}"
            )
            add_btn.clicked.connect(lambda checked=False, p=peer: self._add_peer_as_contact(p))
            row.addWidget(lbl, 1)
            row.addWidget(add_btn)
            self._network_layout.addLayout(row)

    def _add_peer_as_contact(self, peer):
        contact = self._store.add(peer.name, device_id=peer.device_id)
        self._select_contact(contact.id)

    def _refresh_contact_list(self):
        query = self._search.text().strip().lower()
        self._list.clear()
        for contact in self._store.all():
            if query and query not in contact.name.lower() and query not in contact.phone.lower():
                continue
            online = bool(contact.device_id) and self._network.is_online(contact.device_id)
            dot = "🟢 " if online else ("⚪ " if contact.device_id else "")
            item = QListWidgetItem(f"{dot}{contact.name}\n{contact.phone or '—'}")
            item.setData(Qt.ItemDataRole.UserRole, contact.id)
            item.setFont(QFont(Theme.font_ui, 10))
            self._list.addItem(item)
            if contact.id == self._current_id:
                item.setSelected(True)

    def _on_list_item_clicked(self, item: QListWidgetItem):
        self._select_contact(item.data(Qt.ItemDataRole.UserRole))

    def _select_contact(self, contact_id: str):
        contact = self._store.get(contact_id)
        if contact is None:
            return
        self._current_id = contact_id
        w = self._detail_widgets
        w["avatar"].setText(contact.initial())
        w["avatar"].setStyleSheet(f"background-color: {contact.color}; color: white; border-radius: 32px;")
        w["name"].setText(contact.name)
        if not contact.device_id:
            w["network"].setText("нет сетевой привязки")
        elif self._network.is_online(contact.device_id):
            w["network"].setText("🟢 в сети сейчас")
        else:
            w["network"].setText("⚪ не в сети")
        w["phone"].setText(contact.phone or "—")
        w["email"].setText(contact.email or "—")
        w["note"].setText(contact.note or "—")
        self._right_stack.setCurrentWidget(self._detail_page)

    def _start_new_contact(self):
        self._current_id = None
        for field in self._edit_widgets.values():
            field.clear()
        self._right_stack.setCurrentWidget(self._edit_page)
        self._edit_widgets["name"].setFocus()

    def _start_edit(self):
        contact = self._store.get(self._current_id) if self._current_id else None
        if contact is None:
            return
        e = self._edit_widgets
        e["name"].setText(contact.name)
        e["phone"].setText(contact.phone)
        e["email"].setText(contact.email)
        e["note"].setText(contact.note)
        self._right_stack.setCurrentWidget(self._edit_page)

    def _save_edit(self):
        e = self._edit_widgets
        name = e["name"].text().strip()
        if not name:
            e["name"].setFocus()
            return
        phone, email, note = e["phone"].text().strip(), e["email"].text().strip(), e["note"].text().strip()
        if self._current_id:
            self._store.update(self._current_id, name=name, phone=phone, email=email, note=note)
        else:
            contact = self._store.add(name, phone, email, note)
            self._current_id = contact.id
        self._select_contact(self._current_id)

    def _cancel_edit(self):
        if self._current_id:
            self._select_contact(self._current_id)
        else:
            self._right_stack.setCurrentWidget(self._empty_page)

    def _delete_current(self):
        if not self._current_id:
            return
        contact = self._store.get(self._current_id)
        if contact is None:
            return
        confirm = QMessageBox(self)
        confirm.setWindowTitle("Удалить контакт")
        confirm.setText(f"Удалить «{contact.name}» из контактов?")
        confirm.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel)
        confirm.setDefaultButton(QMessageBox.StandardButton.Cancel)
        if confirm.exec() == QMessageBox.StandardButton.Yes:
            self._store.remove(self._current_id)
            self._current_id = None
            self._right_stack.setCurrentWidget(self._empty_page)

    def _open_in_sms(self):
        if not self._current_id:
            return
        AppBus.instance().open_app_requested.emit("sms", {"contact_id": self._current_id})


class ContactsApp(IApp):
    def id(self) -> str:
        return "contacts"

    def name(self) -> str:
        return "Контакты"

    def icon_emoji(self) -> str:
        return "👤"

    def description(self) -> str:
        return "Адресная книга + люди, обнаруженные в локальной сети прямо сейчас."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        initial_id = context.get("contact_id") if context else None
        return ContactsWidget(parent, initial_contact_id=initial_id)

    def preferred_size(self) -> QSize:
        return QSize(660, 540)
