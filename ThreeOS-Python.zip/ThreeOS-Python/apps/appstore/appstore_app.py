"""
Магазин приложений ThreeOS: показывает все приложения системы с описанием.
Базовые приложения всегда на месте — их можно только открыть.
Необязательные (IApp.is_core() == False, например Заметки) можно
установить — тогда они появляются на рабочем столе и в панели задач —
или удалить обратно.
"""
from typing import Optional

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea, QGridLayout,
)

from core.iapp import IApp
from core.theme import Theme
from shell.app_registry import AppRegistry
from services.installed_apps_store import InstalledAppsStore
from services.app_bus import AppBus


class AppCard(QWidget):
    def __init__(self, app: IApp, installed_store: InstalledAppsStore, parent=None):
        super().__init__(parent)
        self._app = app
        self._store = installed_store

        self.setFixedSize(260, 150)
        self.setStyleSheet(
            f"background-color: {Theme.bg_surface_alt.name()}; border-radius: 12px;"
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(4)

        header = QHBoxLayout()
        icon = QLabel(app.icon_emoji())
        icon.setFont(QFont(Theme.font_ui, 20))
        name = QLabel(app.name())
        name.setFont(QFont(Theme.font_display, 12, QFont.Weight.DemiBold))
        name.setStyleSheet(f"color: {Theme.text_primary.name()};")
        header.addWidget(icon)
        header.addWidget(name, 1)
        layout.addLayout(header)

        desc = QLabel(app.description())
        desc.setWordWrap(True)
        desc.setFont(QFont(Theme.font_ui, 9))
        desc.setStyleSheet(f"color: {Theme.text_muted.name()};")
        layout.addWidget(desc, 1)

        btn_row = QHBoxLayout()
        self._open_btn = self._pill_button("Открыть", Theme.accent.name(), "white")
        self._open_btn.clicked.connect(lambda: AppBus.instance().open_app_requested.emit(app.id(), {}))
        btn_row.addWidget(self._open_btn)

        if not app.is_core():
            self._toggle_btn = self._pill_button("", Theme.bg_base.name(), Theme.text_primary.name())
            self._toggle_btn.clicked.connect(self._toggle_installed)
            btn_row.addWidget(self._toggle_btn)
        else:
            self._toggle_btn = None

        btn_row.addStretch()
        layout.addLayout(btn_row)

        self._refresh_state()

    def _pill_button(self, text: str, bg: str, fg: str) -> QPushButton:
        btn = QPushButton(text)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.setStyleSheet(
            f"QPushButton {{ background: {bg}; color: {fg}; border: none; border-radius: 7px; padding: 6px 12px; font-size: 9pt; }}"
            f"QPushButton:hover {{ background: {Theme.border.name()}; }}"
        )
        return btn

    def _toggle_installed(self):
        if self._store.is_installed(self._app.id()):
            self._store.uninstall(self._app.id())
        else:
            self._store.install(self._app.id())
        self._refresh_state()

    def _refresh_state(self):
        if self._app.is_core():
            self._open_btn.setEnabled(True)
            return
        installed = self._store.is_installed(self._app.id())
        self._open_btn.setEnabled(installed)
        if self._toggle_btn:
            self._toggle_btn.setText("Удалить" if installed else "Установить")
            bg = Theme.danger.name() if installed else Theme.accent2.name()
            fg = "white" if installed else "#04302a"
            self._toggle_btn.setStyleSheet(
                f"QPushButton {{ background: {bg}; color: {fg}; border: none; border-radius: 7px;"
                f" padding: 6px 12px; font-size: 9pt; }}"
                f"QPushButton:hover {{ background: {bg}; }}"
            )


class AppStoreWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._installed_store = InstalledAppsStore.instance()

        self.setStyleSheet(f"background-color: {Theme.bg_base.name()};")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 20, 20, 20)
        outer.setSpacing(10)

        title = QLabel("🛒 Магазин приложений")
        title.setFont(QFont(Theme.font_display, 18, QFont.Weight.DemiBold))
        title.setStyleSheet(f"color: {Theme.text_primary.name()};")
        outer.addWidget(title)

        subtitle = QLabel("Базовые приложения всегда с вами. Дополнительные можно установить.")
        subtitle.setFont(QFont(Theme.font_ui, 10))
        subtitle.setStyleSheet(f"color: {Theme.text_muted.name()};")
        outer.addWidget(subtitle)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border: none;")
        grid_container = QWidget()
        self._grid = QGridLayout(grid_container)
        self._grid.setSpacing(14)
        scroll.setWidget(grid_container)
        outer.addWidget(scroll, 1)

        self._installed_store.changed.connect(self._refresh_cards)
        self._refresh_cards()

    def _refresh_cards(self):
        while self._grid.count():
            item = self._grid.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        apps = [a for a in AppRegistry.instance().all_apps() if a.id() != "appstore"]
        apps = sorted(apps, key=lambda a: (not a.is_core(), a.name()))
        columns = 3
        for index, app in enumerate(apps):
            card = AppCard(app, self._installed_store, self)
            row, col = divmod(index, columns)
            self._grid.addWidget(card, row, col)


class AppStoreApp(IApp):
    def id(self) -> str:
        return "appstore"

    def name(self) -> str:
        return "Магазин приложений"

    def icon_emoji(self) -> str:
        return "🛒"

    def description(self) -> str:
        return "Смотрите и устанавливайте приложения ThreeOS."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        return AppStoreWidget(parent)

    def preferred_size(self) -> QSize:
        return QSize(880, 560)
