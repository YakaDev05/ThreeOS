"""
Калькулятор ThreeOS: классическая арифметика на конечном автомате
(как в настоящих калькуляторах — вычисление сразу при нажатии оператора,
а не отложенный разбор выражения с приоритетами).
"""
from typing import Optional

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QWidget, QVBoxLayout, QGridLayout, QLineEdit, QPushButton

from core.iapp import IApp
from core.theme import Theme

# kind: 0 = цифра, 1 = оператор, 2 = служебная кнопка, 3 = равно
_BUTTONS = [
    ("C", 0, 0, 2), ("CE", 0, 1, 2), ("⌫", 0, 2, 2), ("÷", 0, 3, 1),
    ("7", 1, 0, 0), ("8", 1, 1, 0), ("9", 1, 2, 0), ("×", 1, 3, 1),
    ("4", 2, 0, 0), ("5", 2, 1, 0), ("6", 2, 2, 0), ("−", 2, 3, 1),
    ("1", 3, 0, 0), ("2", 3, 1, 0), ("3", 3, 2, 0), ("+", 3, 3, 1),
    ("±", 4, 0, 2), ("0", 4, 1, 0), (".", 4, 2, 2), ("=", 4, 3, 3),
]


class CalculatorWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background-color: {Theme.bg_surface.name()};")

        self._stored_value: float = 0.0
        self._pending_op: str = ""
        self._waiting_for_operand: bool = True
        self._just_evaluated: bool = False

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(14, 14, 14, 14)
        main_layout.setSpacing(10)

        self._display = QLineEdit("0", self)
        self._display.setReadOnly(True)
        self._display.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self._display.setFont(QFont(Theme.font_display, 26, QFont.Weight.Medium))
        self._display.setFixedHeight(72)
        self._display.setStyleSheet(
            f"QLineEdit {{ background-color: {Theme.bg_base.name()}; color: {Theme.text_primary.name()};"
            f" border: none; border-radius: 10px; padding: 0 16px; }}"
        )
        main_layout.addWidget(self._display)

        grid = QGridLayout()
        grid.setSpacing(8)

        for label, row, col, kind in _BUTTONS:
            btn = QPushButton(label, self)
            btn.setFixedSize(64, 56)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setFont(QFont(Theme.font_ui, 13, QFont.Weight.DemiBold))

            fg = "white"
            if kind == 1:
                bg, hover_bg = Theme.accent.name(), Theme.accent_hover.name()
            elif kind == 3:
                bg, hover_bg, fg = Theme.accent2.name(), Theme.accent2.name(), "#04302a"
            else:
                bg, hover_bg = Theme.bg_surface_alt.name(), Theme.border.name()

            btn.setStyleSheet(
                f"QPushButton {{ background-color: {bg}; color: {fg}; border: none; border-radius: 10px; }}"
                f"QPushButton:hover {{ background-color: {hover_bg}; }}"
            )

            if label == "C":
                btn.clicked.connect(self._clear)
            elif label == "CE":
                btn.clicked.connect(self._clear_entry)
            elif label == "⌫":
                btn.clicked.connect(self._backspace)
            elif label == "±":
                btn.clicked.connect(self._toggle_sign)
            elif label == ".":
                btn.clicked.connect(self._decimal)
            elif label == "=":
                btn.clicked.connect(self._equals)
            elif kind == 1:
                btn.clicked.connect(lambda checked=False, op=label: self._operator(op))
            else:
                btn.clicked.connect(lambda checked=False, digit=label: self._digit(digit))

            grid.addWidget(btn, row, col)

        main_layout.addLayout(grid)
        self.setLayout(main_layout)

    def _digit(self, digit: str):
        if self._waiting_for_operand or self._just_evaluated:
            self._display.setText(digit)
            self._waiting_for_operand = False
            self._just_evaluated = False
            return
        cur = self._display.text()
        self._display.setText(digit if cur == "0" else cur + digit)

    def _decimal(self):
        if self._waiting_for_operand or self._just_evaluated:
            self._display.setText("0.")
            self._waiting_for_operand = False
            self._just_evaluated = False
            return
        cur = self._display.text()
        if "." not in cur:
            self._display.setText(cur + ".")

    def _operator(self, op: str):
        current_value = float(self._display.text() or 0)
        if not self._waiting_for_operand:
            if not self._apply_pending_operation(current_value):
                return
        elif not self._pending_op:
            self._stored_value = current_value
        self._pending_op = op
        self._waiting_for_operand = True
        self._just_evaluated = False

    def _equals(self):
        current_value = float(self._display.text() or 0)
        if not self._pending_op:
            self._stored_value = current_value
            self._update_display(self._stored_value)
        elif not self._apply_pending_operation(current_value):
            return
        self._pending_op = ""
        self._waiting_for_operand = True
        self._just_evaluated = True

    def _apply_pending_operation(self, next_value: float) -> bool:
        if not self._pending_op:
            self._stored_value = next_value
        elif self._pending_op == "+":
            self._stored_value += next_value
        elif self._pending_op == "−":
            self._stored_value -= next_value
        elif self._pending_op == "×":
            self._stored_value *= next_value
        elif self._pending_op == "÷":
            if next_value == 0.0:
                self._display.setText("Ошибка")
                self._stored_value = 0.0
                self._pending_op = ""
                self._waiting_for_operand = True
                self._just_evaluated = True
                return False
            self._stored_value /= next_value
        self._update_display(self._stored_value)
        return True

    def _update_display(self, value: float):
        self._display.setText(f"{value:.12g}")

    def _clear(self):
        self._stored_value = 0.0
        self._pending_op = ""
        self._waiting_for_operand = True
        self._just_evaluated = False
        self._display.setText("0")

    def _clear_entry(self):
        self._display.setText("0")
        self._waiting_for_operand = True

    def _backspace(self):
        if self._waiting_for_operand or self._just_evaluated:
            return
        cur = self._display.text()[:-1]
        if cur in ("", "-"):
            cur = "0"
        self._display.setText(cur)

    def _toggle_sign(self):
        value = float(self._display.text() or 0)
        self._update_display(-value)
        self._waiting_for_operand = False


class CalculatorApp(IApp):
    def id(self) -> str:
        return "calculator"

    def name(self) -> str:
        return "Калькулятор"

    def icon_emoji(self) -> str:
        return "🧮"

    def description(self) -> str:
        return "Простой и быстрый калькулятор для повседневных расчётов."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        return CalculatorWidget(parent)

    def preferred_size(self) -> QSize:
        return QSize(320, 460)
