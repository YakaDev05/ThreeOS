"""
Виртуальная файловая система ThreeOS.

Общая для Терминала и Проводника — файл, созданный в одном, сразу виден в
другом (через сигнал changed). Хранится в ~/.threeos/filesystem.json, так
что не пропадает между запусками. Это НЕ доступ к настоящим файлам
компьютера — полностью своя, безопасная песочница.

Важно: сама файловая система НЕ хранит "текущую директорию" — это дало бы
одну общую директорию на все открытые окна Терминала/Проводника сразу
(перешёл в одном — переехали все). Вместо этого каждый вызывающий (каждое
окно Терминала, Проводник) хранит свой cwd самостоятельно и передаёт его
явным параметром — как в настоящих ОС, где у каждого терминала свой cwd,
но все они работают с одной файловой системой.
"""
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PySide6.QtCore import QObject, Signal

DATA_DIR = Path.home() / ".threeos"
FILESYSTEM_FILE = DATA_DIR / "filesystem.json"
DEFAULT_START_PATH = "/home/user"


class VNode:
    def __init__(self, name: str, is_directory: bool, parent: Optional["VNode"] = None):
        self.name = name
        self.is_directory = is_directory
        self.content: str = ""                      # используется только для файлов
        self.children: Dict[str, "VNode"] = {}       # используется только для директорий
        self.parent: Optional["VNode"] = parent

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "is_directory": self.is_directory,
            "content": self.content,
            "children": {k: v.to_dict() for k, v in self.children.items()},
        }

    @staticmethod
    def from_dict(data: dict, parent: Optional["VNode"] = None) -> "VNode":
        node = VNode(data.get("name", ""), bool(data.get("is_directory", False)), parent)
        node.content = data.get("content", "")
        for key, child_data in data.get("children", {}).items():
            node.children[key] = VNode.from_dict(child_data, node)
        return node


class VirtualFileSystem(QObject):
    changed = Signal()

    _instance: Optional["VirtualFileSystem"] = None

    def __init__(self, data_file: Optional[Path] = None):
        super().__init__()
        self._data_file = data_file or FILESYSTEM_FILE
        self._root: Optional[VNode] = None
        self._load_or_seed()

    @classmethod
    def instance(cls) -> "VirtualFileSystem":
        if cls._instance is None:
            cls._instance = VirtualFileSystem()
        return cls._instance

    @classmethod
    def reset_instance_for_tests(cls):
        cls._instance = None

    def default_start_path(self) -> str:
        return DEFAULT_START_PATH

    # ---------- навигация ----------
    def normalize(self, cwd: str, path: str) -> Optional[str]:
        """Резолвит path относительно cwd и возвращает итоговый абсолютный
        путь (или None, если такой директории нет) — этим результатом
        вызывающий код обновляет свой собственный cwd после 'cd'."""
        node = self._resolve_from(cwd, path)
        if node is None or not node.is_directory:
            return None
        return self._build_path(node)

    def list(self, cwd: str, path: str = "") -> List[str]:
        node = self._resolve_from(cwd, path)
        if node is None or not node.is_directory:
            return []
        result = [name + "/" if child.is_directory else name for name, child in node.children.items()]
        result.sort()
        return result

    def list_entries_detailed(self, cwd: str, path: str = "") -> List[Tuple[str, bool]]:
        """Как list(), но возвращает (имя_без_слэша, является_ли_директорией) —
        удобно для Проводника, которому нужна точная информация по типу."""
        node = self._resolve_from(cwd, path)
        if node is None or not node.is_directory:
            return []
        result = [(name, child.is_directory) for name, child in node.children.items()]
        result.sort(key=lambda t: (not t[1], t[0].lower()))
        return result

    # ---------- операции с файлами/директориями (все — в директории cwd) ----------
    def make_directory(self, cwd: str, name: str) -> bool:
        node = self._node_at(cwd)
        if node is None or not node.is_directory or not name or name in node.children:
            return False
        node.children[name] = VNode(name, True, node)
        self._save_and_notify()
        return True

    def create_file(self, cwd: str, name: str, content: str = "") -> bool:
        node = self._node_at(cwd)
        if node is None or not node.is_directory or not name or name in node.children:
            return False
        child = VNode(name, False, node)
        child.content = content
        node.children[name] = child
        self._save_and_notify()
        return True

    def write_file(self, cwd: str, name: str, content: str) -> bool:
        """Создаёт файл или перезаписывает существующий."""
        node = self._node_at(cwd)
        if node is None or not node.is_directory or not name:
            return False
        existing = node.children.get(name)
        if existing is not None:
            if existing.is_directory:
                return False
            existing.content = content
            self._save_and_notify()
            return True
        child = VNode(name, False, node)
        child.content = content
        node.children[name] = child
        self._save_and_notify()
        return True

    def remove_entry(self, cwd: str, name: str) -> bool:
        node = self._node_at(cwd)
        if node is None or name not in node.children:
            return False
        del node.children[name]
        self._save_and_notify()
        return True

    def rename_entry(self, cwd: str, old_name: str, new_name: str) -> bool:
        node = self._node_at(cwd)
        if node is None or old_name not in node.children or not new_name or new_name in node.children:
            return False
        child = node.children.pop(old_name)
        child.name = new_name
        node.children[new_name] = child
        self._save_and_notify()
        return True

    def copy_file(self, cwd: str, name: str, new_name: str) -> bool:
        node = self._node_at(cwd)
        if node is None:
            return False
        source = node.children.get(name)
        if source is None or source.is_directory or not new_name or new_name in node.children:
            return False
        copy = VNode(new_name, False, node)
        copy.content = source.content
        node.children[new_name] = copy
        self._save_and_notify()
        return True

    def read_file(self, cwd: str, name: str) -> Tuple[str, bool]:
        """Возвращает (содержимое, найден_ли_файл)."""
        node = self._node_at(cwd)
        if node is None:
            return "", False
        child = node.children.get(name)
        if child is None or child.is_directory:
            return "", False
        return child.content, True

    def exists(self, cwd: str, name: str) -> bool:
        node = self._node_at(cwd)
        return node is not None and name in node.children

    def is_directory_entry(self, cwd: str, name: str) -> bool:
        node = self._node_at(cwd)
        if node is None or name not in node.children:
            return False
        return node.children[name].is_directory

    # ---------- расширенные операции для команд Терминала ----------
    def find(self, fragment: str) -> List[str]:
        """Рекурсивный поиск по всей файловой системе от корня."""
        fragment = fragment.lower()
        matches: List[str] = []

        def walk(node: VNode):
            for child in node.children.values():
                if fragment in child.name.lower():
                    matches.append(self._build_path(child))
                if child.is_directory:
                    walk(child)

        walk(self._root)
        return matches

    def tree(self, cwd: str, path: str = "") -> str:
        """Дерево каталогов от cwd (или от path, если указан)."""
        start = self._resolve_from(cwd, path)
        if start is None or not start.is_directory:
            return ""
        lines = [self._build_path(start)]

        def walk(node: VNode, prefix: str):
            entries = sorted(node.children.values(), key=lambda n: (not n.is_directory, n.name.lower()))
            for i, child in enumerate(entries):
                is_last = i == len(entries) - 1
                connector = "└── " if is_last else "├── "
                suffix = "/" if child.is_directory else ""
                lines.append(f"{prefix}{connector}{child.name}{suffix}")
                if child.is_directory:
                    walk(child, prefix + ("    " if is_last else "│   "))

        walk(start, "")
        return "\n".join(lines)

    # ---------- вспомогательное ----------
    def _node_at(self, absolute_path: str) -> Optional[VNode]:
        """Резолвит канонический абсолютный путь (обычно чей-то сохранённый
        cwd) напрямую от корня — без поддержки '..'/'.' (cwd уже канонический)."""
        node = self._root
        for part in (p for p in absolute_path.split("/") if p):
            if not node.is_directory or part not in node.children:
                return None
            node = node.children[part]
        return node

    def _resolve_from(self, cwd: str, path: str) -> Optional[VNode]:
        base = self._node_at(cwd) or self._root
        if not path:
            return base
        node = self._root if path.startswith("/") else base
        for part in (p for p in path.split("/") if p):
            if part == ".":
                continue
            if part == "..":
                if node.parent is not None:
                    node = node.parent
                continue
            if not node.is_directory or part not in node.children:
                return None
            node = node.children[part]
        return node

    def _build_path(self, node: VNode) -> str:
        if node is self._root:
            return "/"
        parts = []
        n: Optional[VNode] = node
        while n is not None and n is not self._root:
            parts.append(n.name)
            n = n.parent
        parts.reverse()
        return "/" + "/".join(parts)

    def _save_and_notify(self):
        self._save()
        self.changed.emit()

    def _load_or_seed(self):
        if self._data_file.exists():
            try:
                data = json.loads(self._data_file.read_text(encoding="utf-8"))
                self._root = VNode.from_dict(data)
                return
            except (json.JSONDecodeError, OSError, TypeError, KeyError):
                pass
        self._root = VNode("/", True, None)
        self._seed_default_files()
        self._save()

    def _save(self):
        try:
            self._data_file.parent.mkdir(parents=True, exist_ok=True)
            self._data_file.write_text(json.dumps(self._root.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass

    def _seed_default_files(self):
        self.make_directory("/", "home")
        self.make_directory("/home", "user")
        self.create_file(
            "/home/user", "readme.txt",
            "Добро пожаловать в ThreeOS!\n\n"
            "Это виртуальная файловая система — общая для Терминала и\n"
            "Проводника. Она сохраняется на диск и не трогает настоящие\n"
            "файлы на вашем компьютере.\n\n"
            "Введите 'help' в Терминале, чтобы увидеть список команд.",
        )
        self.make_directory("/home/user", "documents")
        self.make_directory("/", "system")
        self.create_file("/system", "version.txt", "ThreeOS версия 1.0\nАвтор: Said (Yaka) Hamidov\n")
