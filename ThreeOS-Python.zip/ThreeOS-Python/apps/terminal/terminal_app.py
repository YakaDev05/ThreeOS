"""
Виджет Терминала: панель вывода + строка ввода, подключённые к
ShellInterpreter/VirtualFileSystem.
"""
from typing import Optional

from PySide6.QtCore import QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPlainTextEdit, QLabel, QFrame

from core.iapp import IApp
from core.theme import Theme
from apps.terminal.virtual_file_system import VirtualFileSystem
from apps.terminal.shell_interpreter import ShellInterpreter
from apps.terminal.terminal_input import TerminalInput


class TerminalWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._fs = VirtualFileSystem.instance()
        self._shell = ShellInterpreter(self._fs)

        self.setStyleSheet(f"background-color: {Theme.bg_base.name()};")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(6)

        self._output = QPlainTextEdit(self)
        self._output.setReadOnly(True)
        self._output.setFont(QFont(Theme.font_mono, 10))
        self._output.setFrameShape(QFrame.Shape.NoFrame)
        self._output.setStyleSheet(
            f"QPlainTextEdit {{ background-color: {Theme.bg_base.name()};"
            f" color: {Theme.text_primary.name()}; border: none; }}"
        )
        layout.addWidget(self._output, 1)

        input_row = QHBoxLayout()
        input_row.setSpacing(6)

        self._prompt_label = QLabel(self)
        self._prompt_label.setFont(QFont(Theme.font_mono, 10, QFont.Weight.DemiBold))
        self._prompt_label.setStyleSheet(f"color: {Theme.accent2.name()};")

        self._input = TerminalInput(self)
        self._input.setFont(QFont(Theme.font_mono, 10))
        self._input.setFrame(False)
        self._input.setStyleSheet(
            f"QLineEdit {{ background-color: {Theme.bg_base.name()};"
            f" color: {Theme.text_primary.name()}; border: none; }}"
        )

        input_row.addWidget(self._prompt_label, 0)
        input_row.addWidget(self._input, 1)
        layout.addLayout(input_row)

        self.setLayout(layout)

        self._input.returnPressed.connect(self._handle_command)

        self._print_banner()
        self._prompt_label.setText(self._shell.prompt())
        self._input.setFocus()

    def _handle_command(self):
        cmd = self._input.text()
        self._append_output(self._prompt_label.text() + cmd)
        self._input.commit_to_history(cmd)
        self._input.clear()

        if cmd.strip():
            result, clear_requested = self._shell.execute(cmd)
            if clear_requested:
                self._output.clear()
            elif result:
                self._append_output(result)

        self._prompt_label.setText(self._shell.prompt())

    def _append_output(self, text: str):
        self._output.appendPlainText(text)
        bar = self._output.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _print_banner(self):
        self._append_output("ThreeOS [Версия 1.0] — терминал")
        self._append_output("Автор: Said (Yaka) Hamidov")
        self._append_output("Введите 'help' для списка команд.\n")


class TerminalApp(IApp):
    def id(self) -> str:
        return "terminal"

    def name(self) -> str:
        return "Терминал"

    def icon_emoji(self) -> str:
        return "💻"

    def description(self) -> str:
        return "Командная строка ThreeOS с собственной виртуальной файловой системой."

    def create_widget(self, parent: Optional[QWidget] = None, context: Optional[dict] = None) -> QWidget:
        return TerminalWidget(parent)

    def preferred_size(self) -> QSize:
        return QSize(660, 440)
