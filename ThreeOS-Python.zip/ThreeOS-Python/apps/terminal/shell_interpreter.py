"""
Разбирает командную строку и выполняет её над VirtualFileSystem.
Не знает ничего о Qt-виджетах — чистая логика, поэтому легко тестируется
отдельно от интерфейса.

Хранит свой собственный cwd (текущую директорию) — так что если открыто
несколько окон Терминала, у каждого своя текущая папка, хотя все они
работают с одной и той же (общей) файловой системой.
"""
import ast
import operator
from datetime import datetime
from typing import List, Tuple

from apps.terminal.virtual_file_system import VirtualFileSystem

_ABOUT_BANNER = r""" _____ _                    ___  ____  
|_   _| |__  _ __ ___  ___ / _ \/ ___| 
  | | | '_ \| '__/ _ \/ _ \ | | \___ \ 
  | | | | | | | |  __/  __/ |_| |___) |
  |_| |_| |_|_|  \___|\___|\___/|____/ 
                                       
"""

_WEEKDAYS_RU = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]
_MONTHS_RU = [
    "января", "февраля", "марта", "апреля", "мая", "июня",
    "июля", "августа", "сентября", "октября", "ноября", "декабря",
]

_CALC_OPERATORS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.Mod: operator.mod, ast.Pow: operator.pow,
    ast.USub: operator.neg, ast.UAdd: operator.pos,
}


def _safe_calc_eval(node):
    """Безопасно вычисляет арифметику из ast-дерева: только числа и
    +-*/%**, никаких имён, вызовов функций и т.п. — в отличие от eval()
    не может выполнить произвольный код."""
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _CALC_OPERATORS:
        return _CALC_OPERATORS[type(node.op)](_safe_calc_eval(node.left), _safe_calc_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _CALC_OPERATORS:
        return _CALC_OPERATORS[type(node.op)](_safe_calc_eval(node.operand))
    raise ValueError("недопустимое выражение")


class ShellInterpreter:
    def __init__(self, fs: VirtualFileSystem):
        self._fs = fs
        self._cwd = fs.default_start_path()
        self._history: List[str] = []

    def prompt(self) -> str:
        return f"user@ThreeOS:{self._cwd}$ "

    def command_history(self) -> List[str]:
        return list(self._history)

    def execute(self, command_line: str) -> Tuple[str, bool]:
        """Выполняет команду. Возвращает (текст_для_вывода, clear_requested)."""
        tokens = command_line.split()
        if not tokens:
            return "", False

        cmd, args = tokens[0], tokens[1:]
        if cmd != "history":  # сама история не должна бесконечно включать себя
            self._history.append(command_line)

        if cmd == "clear":
            return "", True

        handlers = {
            "help": lambda: self._cmd_help(),
            "man": lambda: self._cmd_man(args),
            "ls": lambda: self._cmd_ls(args),
            "cd": lambda: self._cmd_cd(args),
            "pwd": lambda: self._cmd_pwd(),
            "cat": lambda: self._cmd_cat(args),
            "echo": lambda: self._cmd_echo(args),
            "mkdir": lambda: self._cmd_mkdir(args),
            "touch": lambda: self._cmd_touch(args),
            "rm": lambda: self._cmd_rm(args),
            "mv": lambda: self._cmd_mv(args),
            "cp": lambda: self._cmd_cp(args),
            "find": lambda: self._cmd_find(args),
            "tree": lambda: self._cmd_tree(args),
            "wc": lambda: self._cmd_wc(args),
            "head": lambda: self._cmd_head(args),
            "tail": lambda: self._cmd_tail(args),
            "grep": lambda: self._cmd_grep(args),
            "history": lambda: self._cmd_history(),
            "calc": lambda: self._cmd_calc(args),
            "whoami": lambda: self._cmd_whoami(),
            "date": lambda: self._cmd_date(),
            "about": lambda: self._cmd_about(),
            "neofetch": lambda: self._cmd_about(),
        }
        if cmd in handlers:
            return handlers[cmd](), False
        return f"Команда не найдена: {cmd}\nВведите 'help' для списка команд.", False

    # ---------- справка ----------
    def _cmd_help(self) -> str:
        return (
            "Доступные команды (man <команда> — подробнее):\n"
            "  help, man             справка\n"
            "  ls, cd, pwd           навигация\n"
            "  cat, echo             чтение и запись файлов\n"
            "  mkdir, touch, rm      создание и удаление\n"
            "  mv, cp                переименование и копирование\n"
            "  find, tree            поиск и структура каталогов\n"
            "  wc, head, tail, grep  работа с содержимым файлов\n"
            "  calc                  калькулятор (calc 2+2*2)\n"
            "  history, whoami, date, about, clear"
        )

    def _cmd_man(self, args: List[str]) -> str:
        pages = {
            "ls": "ls [путь] — список файлов и директорий. Без аргумента — текущая директория.",
            "cd": "cd <путь> — перейти в директорию. '..' — на уровень выше, '/' — в корень.",
            "pwd": "pwd — показать текущий путь.",
            "cat": "cat <файл> — показать содержимое файла.",
            "echo": "echo <текст> — вывести текст. 'echo текст > файл' — записать текст в файл (перезаписывает).",
            "mkdir": "mkdir <имя> — создать директорию в текущей папке.",
            "touch": "touch <имя> — создать пустой файл.",
            "rm": "rm <имя> — удалить файл или директорию (без подтверждения — будьте внимательны).",
            "mv": "mv <старое_имя> <новое_имя> — переименовать файл или директорию в текущей папке.",
            "cp": "cp <файл> <новое_имя> — скопировать файл под новым именем в той же папке.",
            "find": "find <фрагмент> — найти все файлы/директории, чьё имя содержит фрагмент (по всей системе).",
            "tree": "tree [путь] — показать дерево каталогов от текущей (или указанной) директории.",
            "wc": "wc <файл> — количество строк, слов и символов в файле.",
            "head": "head <файл> [n] — первые n строк файла (по умолчанию 10).",
            "tail": "tail <файл> [n] — последние n строк файла (по умолчанию 10).",
            "grep": "grep <образец> <файл> — строки файла, содержащие образец.",
            "calc": "calc <выражение> — вычислить арифметику, например: calc (2+3)*4",
            "history": "history — список команд, введённых в этой сессии.",
            "whoami": "whoami — текущий пользователь.",
            "date": "date — текущая дата и время.",
            "about": "about — информация о ThreeOS.",
            "clear": "clear — очистить экран терминала.",
        }
        if not args:
            return "Укажите команду: man <команда>. Например: man grep"
        page = pages.get(args[0])
        return page if page else f"Нет справки по '{args[0]}'. Введите 'help' для списка команд."

    # ---------- файлы и директории ----------
    def _cmd_ls(self, args: List[str]) -> str:
        path = args[0] if args else ""
        entries = self._fs.list(self._cwd, path)
        return "  ".join(entries) if entries else "(пусто)"

    def _cmd_cd(self, args: List[str]) -> str:
        target = args[0] if args else self._fs.default_start_path()
        new_cwd = self._fs.normalize(self._cwd, target)
        if new_cwd is None:
            return f"cd: директория не найдена: {target}"
        self._cwd = new_cwd
        return ""

    def _cmd_pwd(self) -> str:
        return self._cwd

    def _cmd_cat(self, args: List[str]) -> str:
        if not args:
            return "cat: укажите имя файла"
        content, ok = self._fs.read_file(self._cwd, args[0])
        if not ok:
            return f"cat: файл не найден: {args[0]}"
        return content

    def _cmd_echo(self, args: List[str]) -> str:
        if ">" in args:
            idx = args.index(">")
            text = " ".join(args[:idx])
            if idx + 1 >= len(args):
                return "echo: укажите имя файла после '>'"
            self._fs.write_file(self._cwd, args[idx + 1], text)
            return ""
        return " ".join(args)

    def _cmd_mkdir(self, args: List[str]) -> str:
        if not args:
            return "mkdir: укажите имя директории"
        if not self._fs.make_directory(self._cwd, args[0]):
            return f"mkdir: не удалось создать '{args[0]}' (уже существует?)"
        return ""

    def _cmd_touch(self, args: List[str]) -> str:
        if not args:
            return "touch: укажите имя файла"
        self._fs.create_file(self._cwd, args[0])
        return ""

    def _cmd_rm(self, args: List[str]) -> str:
        if not args:
            return "rm: укажите имя файла или директории"
        if not self._fs.remove_entry(self._cwd, args[0]):
            return f"rm: не найдено: {args[0]}"
        return ""

    def _cmd_mv(self, args: List[str]) -> str:
        if len(args) < 2:
            return "mv: укажите старое и новое имя: mv старое новое"
        if not self._fs.rename_entry(self._cwd, args[0], args[1]):
            return f"mv: не удалось переименовать '{args[0]}' в '{args[1]}'"
        return ""

    def _cmd_cp(self, args: List[str]) -> str:
        if len(args) < 2:
            return "cp: укажите файл и новое имя: cp файл новое_имя"
        if not self._fs.copy_file(self._cwd, args[0], args[1]):
            return f"cp: не удалось скопировать '{args[0]}' (файл не найден или '{args[1]}' уже существует)"
        return ""

    def _cmd_find(self, args: List[str]) -> str:
        if not args:
            return "find: укажите фрагмент имени для поиска"
        matches = self._fs.find(args[0])
        return "\n".join(matches) if matches else "Ничего не найдено"

    def _cmd_tree(self, args: List[str]) -> str:
        path = args[0] if args else ""
        result = self._fs.tree(self._cwd, path)
        return result if result else "tree: директория не найдена"

    # ---------- содержимое файлов ----------
    def _cmd_wc(self, args: List[str]) -> str:
        if not args:
            return "wc: укажите имя файла"
        content, ok = self._fs.read_file(self._cwd, args[0])
        if not ok:
            return f"wc: файл не найден: {args[0]}"
        lines = content.splitlines()
        words = content.split()
        return f"{len(lines)} строк  {len(words)} слов  {len(content)} символов  {args[0]}"

    def _cmd_head(self, args: List[str]) -> str:
        return self._head_or_tail(args, from_start=True)

    def _cmd_tail(self, args: List[str]) -> str:
        return self._head_or_tail(args, from_start=False)

    def _head_or_tail(self, args: List[str], from_start: bool) -> str:
        if not args:
            return "укажите имя файла"
        count = 10
        if len(args) > 1:
            try:
                count = max(1, int(args[1]))
            except ValueError:
                pass
        content, ok = self._fs.read_file(self._cwd, args[0])
        if not ok:
            return f"файл не найден: {args[0]}"
        lines = content.splitlines()
        chosen = lines[:count] if from_start else lines[-count:]
        return "\n".join(chosen) if chosen else "(пусто)"

    def _cmd_grep(self, args: List[str]) -> str:
        if len(args) < 2:
            return "grep: укажите образец и файл: grep текст файл"
        pattern, filename = args[0], args[1]
        content, ok = self._fs.read_file(self._cwd, filename)
        if not ok:
            return f"grep: файл не найден: {filename}"
        matches = [line for line in content.splitlines() if pattern in line]
        return "\n".join(matches) if matches else "Совпадений не найдено"

    # ---------- разное ----------
    def _cmd_history(self) -> str:
        if not self._history:
            return "(история пуста)"
        return "\n".join(f"{i + 1}  {cmd}" for i, cmd in enumerate(self._history))

    def _cmd_calc(self, args: List[str]) -> str:
        if not args:
            return "calc: укажите выражение, например: calc 2+2*2"
        expr = " ".join(args)
        try:
            tree = ast.parse(expr, mode="eval")
            result = _safe_calc_eval(tree.body)
            return f"{expr} = {result:g}" if isinstance(result, float) else f"{expr} = {result}"
        except ZeroDivisionError:
            return "calc: деление на ноль"
        except (SyntaxError, ValueError, TypeError, OverflowError):
            return "calc: не удалось вычислить — поддерживаются только числа и + - * / % **"

    def _cmd_whoami(self) -> str:
        return "user"

    def _cmd_date(self) -> str:
        # Названия дня недели/месяца заданы явно на русском, чтобы не зависеть
        # от локали операционной системы (по умолчанию она чаще английская).
        now = datetime.now()
        weekday = _WEEKDAYS_RU[now.weekday()]
        month = _MONTHS_RU[now.month - 1]
        return f"{weekday}, {now.day} {month} {now.year}, {now.strftime('%H:%M:%S')}"

    def _cmd_about(self) -> str:
        return (
            _ABOUT_BANNER
            + "\nThreeOS — операционная система\n"
            "Автор: Said (Yaka) Hamidov\n"
            "Версия: 1.0\n"
            "Оболочка: Python 3 / PySide6"
        )
