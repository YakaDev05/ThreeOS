"""
QLineEdit с историей команд: стрелки вверх/вниз пролистывают ранее
введённые команды, как в настоящем терминале.
"""
from typing import List

from PySide6.QtCore import Qt
from PySide6.QtGui import QKeyEvent
from PySide6.QtWidgets import QLineEdit


class TerminalInput(QLineEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._history: List[str] = []
        self._history_index: int = 0

    def commit_to_history(self, cmd: str):
        if cmd:
            self._history.append(cmd)
        self._history_index = len(self._history)

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() == Qt.Key.Key_Up:
            if self._history_index > 0:
                self._history_index -= 1
                self.setText(self._history[self._history_index])
            return
        if event.key() == Qt.Key.Key_Down:
            if self._history_index < len(self._history) - 1:
                self._history_index += 1
                self.setText(self._history[self._history_index])
            else:
                self._history_index = len(self._history)
                self.clear()
            return
        super().keyPressEvent(event)
