#!/usr/bin/env python3
"""
ThreeOS Account Server — регистрация аккаунтов по номеру телефона и
доставка сообщений между ними. Это то, что позволяет СМС в ThreeOS
доходить до конкретного номера, даже если собеседник не в той же
локальной сети (в отличие от services/network_service.py — того
LAN-обнаружения, которое работает вообще без сервера).

Специально написан на чистом stdlib (без Qt, без сторонних пакетов) —
чтобы его можно было запустить на любом сервере/VPS/Raspberry Pi без
установки лишнего. Клиент (ThreeOS-приложение) — это единственное, что
использует PySide6; сам сервер не показывает никакого окна.

ВАЖНО О БЕЗОПАСНОСТИ: пароли хранятся хешированными (PBKDF2 + соль на
каждого пользователя), но соединение НЕ шифруется (обычный TCP, без TLS).
Это подходит для игры/хобби-проекта с друзьями, но не для реального
использования с настоящими паролями и приватной перепиской — трафик
может прочитать любой, кто видит сеть между клиентом и сервером.

Протокол: TCP, одна JSON-команда на строку (разделитель — перевод строки).

Запуск:
    python3 threeos_server.py [--host 0.0.0.0] [--port 51950]
"""
import argparse
import asyncio
import hashlib
import hmac
import json
import secrets
import time
from pathlib import Path
from typing import Dict, List, Optional

DATA_FILE = Path(__file__).resolve().parent / "server_data.json"
PBKDF2_ITERATIONS = 100_000


def hash_password(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), PBKDF2_ITERATIONS).hex()


class AccountServer:
    def __init__(self, data_file: Path = DATA_FILE):
        self._data_file = data_file
        self.accounts: Dict[str, dict] = {}     # phone -> {"salt","hash","name"}
        self.queued: Dict[str, list] = {}        # phone -> [message dict, ...]
        self.online: Dict[str, asyncio.StreamWriter] = {}  # phone -> writer (не сохраняется на диск)
        self._load()

    # ---------- персистентность ----------
    def _load(self):
        if not self._data_file.exists():
            return
        try:
            data = json.loads(self._data_file.read_text(encoding="utf-8"))
            self.accounts = data.get("accounts", {})
            self.queued = data.get("queued", {})
        except (json.JSONDecodeError, OSError):
            pass

    def _save(self):
        try:
            payload = {"accounts": self.accounts, "queued": self.queued}
            self._data_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass

    # ---------- аккаунты ----------
    def register(self, phone: str, password: str, name: str) -> (bool, str):
        phone = phone.strip()
        if not phone or not password:
            return False, "Укажите номер и пароль"
        if phone in self.accounts:
            return False, "Этот номер уже зарегистрирован"
        salt = secrets.token_hex(16)
        self.accounts[phone] = {"salt": salt, "hash": hash_password(password, salt), "name": name or phone}
        self._save()
        return True, "OK"

    def authenticate(self, phone: str, password: str) -> bool:
        account = self.accounts.get(phone)
        if not account:
            return False
        return hmac.compare_digest(account["hash"], hash_password(password, account["salt"]))

    def display_name_of(self, phone: str) -> str:
        account = self.accounts.get(phone)
        return account["name"] if account else phone

    # ---------- сообщения ----------
    async def deliver_or_queue(self, from_phone: str, to_phone: str, text: str, client_msg_id: str) -> (bool, bool):
        """Возвращает (ok, queued). ok=False только если получатель вообще не
        зарегистрирован — во всех остальных случаях сообщение либо уходит
        сразу (получатель на линии), либо остаётся в очереди до его входа."""
        if to_phone not in self.accounts:
            return False, False

        payload = {
            "type": "message",
            "from_phone": from_phone,
            "from_name": self.display_name_of(from_phone),
            "text": text,
            "timestamp": time.time(),
            "client_msg_id": client_msg_id,
        }
        writer = self.online.get(to_phone)
        if writer is not None:
            try:
                await _send(writer, payload)
                return True, False
            except (ConnectionError, OSError):
                self.online.pop(to_phone, None)

        self.queued.setdefault(to_phone, []).append(payload)
        self._save()
        return True, True

    def pop_queued(self, phone: str) -> List[dict]:
        pending = self.queued.pop(phone, [])
        if pending:
            self._save()
        return pending


async def _send(writer: asyncio.StreamWriter, obj: dict):
    line = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
    writer.write(line)
    await writer.drain()


async def handle_client(server: AccountServer, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    authed_phone: Optional[str] = None
    peer = writer.get_extra_info("peername")
    print(f"[+] соединение от {peer}")
    try:
        while True:
            line = await reader.readline()
            if not line:
                break
            try:
                msg = json.loads(line.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            mtype = msg.get("type")

            if mtype == "register":
                ok, reason = server.register(msg.get("phone", ""), msg.get("password", ""), msg.get("name", ""))
                await _send(writer, {"type": "register_result", "ok": ok, "reason": reason})
                print(f"    register {msg.get('phone')!r} -> {ok} ({reason})")

            elif mtype == "login":
                phone, password = msg.get("phone", ""), msg.get("password", "")
                if server.authenticate(phone, password):
                    authed_phone = phone
                    server.online[phone] = writer
                    await _send(writer, {"type": "login_result", "ok": True, "reason": "OK"})
                    print(f"    login {phone!r} -> OK")
                    for pending in server.pop_queued(phone):
                        await _send(writer, pending)
                else:
                    await _send(writer, {"type": "login_result", "ok": False, "reason": "Неверный номер или пароль"})
                    print(f"    login {phone!r} -> FAILED")

            elif mtype == "send_message" and authed_phone:
                to_phone = msg.get("to_phone", "")
                text = msg.get("text", "")
                client_msg_id = msg.get("client_msg_id", "")
                ok, queued = await server.deliver_or_queue(authed_phone, to_phone, text, client_msg_id)
                await _send(writer, {
                    "type": "send_result", "ok": ok, "queued": queued,
                    "to_phone": to_phone, "client_msg_id": client_msg_id,
                    "reason": "" if ok else "Номер не зарегистрирован",
                })

    except (ConnectionError, OSError):
        pass
    finally:
        if authed_phone and server.online.get(authed_phone) is writer:
            del server.online[authed_phone]
        print(f"[-] отключение {peer} (phone={authed_phone})")
        writer.close()


async def main():
    parser = argparse.ArgumentParser(description="ThreeOS Account Server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=51950)
    args = parser.parse_args()

    server_state = AccountServer()
    srv = await asyncio.start_server(lambda r, w: handle_client(server_state, r, w), args.host, args.port)
    addrs = ", ".join(str(s.getsockname()) for s in srv.sockets)
    print(f"ThreeOS Account Server слушает на {addrs}")
    print(f"Зарегистрировано аккаунтов: {len(server_state.accounts)}")
    async with srv:
        await srv.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nОстановлено.")
