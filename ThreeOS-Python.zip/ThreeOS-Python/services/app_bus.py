"""
AppBus — лёгкая шина событий для связи между независимыми приложениями.

Приложения ThreeOS не хранят прямых ссылок друг на друга (Контакты ничего
не знают о СМС, и наоборот) — это держит архитектуру простой и позволяет
менять/удалять приложения независимо. Но иногда одному приложению нужно
попросить открыть другое в конкретном состоянии — например, кнопка
«Написать» в Контактах должна открыть СМС с уже выбранным диалогом.
Для этого и нужна эта шина: DesktopWindow подписывается на неё один раз
при старте, а любое приложение может попросить открыть другое, не зная,
кто на самом деле обработает эту просьбу.
"""
from typing import Optional

from PySide6.QtCore import QObject, Signal


class AppBus(QObject):
    _instance: Optional["AppBus"] = None

    open_app_requested = Signal(str, dict)  # app_id, context

    @classmethod
    def instance(cls) -> "AppBus":
        if cls._instance is None:
            cls._instance = AppBus()
        return cls._instance
