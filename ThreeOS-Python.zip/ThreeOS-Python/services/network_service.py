"""
NetworkService — обнаружение других запущенных ThreeOS в локальной сети
(UDP-broadcast) и прямой обмен сообщениями между ними (TCP), без какого-либо
центрального сервера-посредника.

Это то, что делает СМС по-настоящему многопользовательскими: сообщение
реально уходит по сети на другой компьютер, и его набирает живой человек —
но только пока оба ThreeOS запущены в одной локальной сети (один Wi-Fi/LAN).
Через интернет (в разных сетях) это напрямую не работает — для этого нужен
отдельный сервер-посредник, которого здесь нет и который каждый раз должен
где-то жить постоянно.
"""
import json
import time
from dataclasses import dataclass
from typing import Dict, Optional

from PySide6.QtCore import QObject, Signal, QTimer
from PySide6.QtNetwork import QUdpSocket, QTcpServer, QTcpSocket, QHostAddress

from services.identity import Identity

DISCOVERY_PORT = 51999
MESSAGING_PORT = 51998
ANNOUNCE_INTERVAL_MS = 3000
PEER_TIMEOUT_MS = 9000


@dataclass
class Peer:
    device_id: str
    name: str
    address: str
    tcp_port: int
    last_seen_ms: int


class NetworkService(QObject):
    peers_changed = Signal()
    message_received = Signal(str, str, str)  # from_device_id, from_name, text

    _instance: Optional["NetworkService"] = None

    def __init__(self, messaging_port: int = MESSAGING_PORT, identity: Optional[Identity] = None):
        super().__init__()
        self._identity = identity or Identity.instance()
        self._messaging_port = messaging_port
        self._peers: Dict[str, Peer] = {}
        self._sockets_in_flight = []  # держим ссылки, пока сокет не закроется

        self._udp = QUdpSocket(self)
        self._udp.bind(DISCOVERY_PORT, QUdpSocket.BindFlag.ShareAddress | QUdpSocket.BindFlag.ReuseAddressHint)
        self._udp.readyRead.connect(self._on_udp_ready_read)

        self._tcp_server = QTcpServer(self)
        self._tcp_server.newConnection.connect(self._on_new_connection)
        self._tcp_server.listen(QHostAddress.SpecialAddress.Any, self._messaging_port)

        self._announce_timer = QTimer(self)
        self._announce_timer.timeout.connect(self._announce)
        self._announce_timer.start(ANNOUNCE_INTERVAL_MS)

        self._cleanup_timer = QTimer(self)
        self._cleanup_timer.timeout.connect(self._cleanup_stale_peers)
        self._cleanup_timer.start(2000)

        QTimer.singleShot(200, self._announce)  # объявиться сразу, не дожидаясь первого тика

    @classmethod
    def instance(cls) -> "NetworkService":
        if cls._instance is None:
            cls._instance = NetworkService()
        return cls._instance

    @classmethod
    def reset_instance_for_tests(cls):
        cls._instance = None

    def peers(self) -> Dict[str, Peer]:
        return dict(self._peers)

    def is_online(self, device_id: str) -> bool:
        return device_id in self._peers

    def send_message(self, device_id: str, text: str) -> bool:
        """Пытается доставить сообщение напрямую собеседнику по сети.
        Возвращает True, если соединение установлено и данные отправлены."""
        peer = self._peers.get(device_id)
        if peer is None:
            return False
        socket = QTcpSocket(self)
        socket.connectToHost(peer.address, peer.tcp_port)
        if not socket.waitForConnected(1500):
            socket.deleteLater()
            return False
        payload = json.dumps({
            "type": "message",
            "from_device_id": self._identity.device_id,
            "from_name": self._identity.display_name,
            "text": text,
        }).encode("utf-8")
        socket.write(payload)
        socket.waitForBytesWritten(1500)
        socket.disconnectFromHost()
        socket.deleteLater()
        return True

    # ---------- обнаружение ----------
    def _announce(self):
        payload = json.dumps({
            "type": "hello",
            "device_id": self._identity.device_id,
            "name": self._identity.display_name,
            "tcp_port": self._messaging_port,
        }).encode("utf-8")
        self._udp.writeDatagram(payload, QHostAddress.SpecialAddress.Broadcast, DISCOVERY_PORT)

    def _on_udp_ready_read(self):
        while self._udp.hasPendingDatagrams():
            datagram = self._udp.receiveDatagram()
            self._handle_datagram(bytes(datagram.data()), datagram.senderAddress().toString())

    def _handle_datagram(self, raw: bytes, sender_address: str):
        try:
            data = json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return
        if data.get("type") != "hello":
            return
        device_id = data.get("device_id")
        if not device_id or device_id == self._identity.device_id:
            return  # не добавляем самих себя в список "людей в сети"
        peer = Peer(
            device_id=device_id,
            name=data.get("name") or "Без имени",
            address=sender_address,
            tcp_port=int(data.get("tcp_port", self._messaging_port)),
            last_seen_ms=_now_ms(),
        )
        is_new = device_id not in self._peers
        self._peers[device_id] = peer
        if is_new:
            self.peers_changed.emit()

    def _cleanup_stale_peers(self):
        now = _now_ms()
        stale = [pid for pid, p in self._peers.items() if now - p.last_seen_ms > PEER_TIMEOUT_MS]
        if not stale:
            return
        for pid in stale:
            del self._peers[pid]
        self.peers_changed.emit()

    # ---------- приём сообщений ----------
    def _on_new_connection(self):
        while self._tcp_server.hasPendingConnections():
            socket = self._tcp_server.nextPendingConnection()
            self._sockets_in_flight.append(socket)
            socket.readyRead.connect(lambda s=socket: self._on_socket_ready_read(s))
            socket.disconnected.connect(lambda s=socket: self._forget_socket(s))

    def _forget_socket(self, socket: QTcpSocket):
        if socket in self._sockets_in_flight:
            self._sockets_in_flight.remove(socket)
        socket.deleteLater()

    def _on_socket_ready_read(self, socket: QTcpSocket):
        raw = bytes(socket.readAll())
        try:
            data = json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return
        if data.get("type") == "message":
            self.message_received.emit(
                data.get("from_device_id", ""), data.get("from_name", "Неизвестный"), data.get("text", "")
            )


def _now_ms() -> int:
    return int(time.time() * 1000)
