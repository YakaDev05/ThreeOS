"""
InstalledAppsStore — какие необязательные приложения "установлены" через
Магазин приложений. Базовые приложения (IApp.is_core() == True) всегда
на рабочем столе и здесь не участвуют; только опциональные — такие как
Заметки — включаются/выключаются через эту запись и Магазин приложений.
"""
import json
from pathlib import Path
from typing import Optional, Set

from PySide6.QtCore import QObject, Signal

DATA_DIR = Path.home() / ".threeos"
INSTALLED_FILE = DATA_DIR / "installed_apps.json"


class InstalledAppsStore(QObject):
    changed = Signal()

    _instance: Optional["InstalledAppsStore"] = None

    def __init__(self, data_file: Optional[Path] = None):
        super().__init__()
        self._data_file = data_file or INSTALLED_FILE
        self._installed: Set[str] = set()
        self._load()

    @classmethod
    def instance(cls) -> "InstalledAppsStore":
        if cls._instance is None:
            cls._instance = InstalledAppsStore()
        return cls._instance

    @classmethod
    def reset_instance_for_tests(cls):
        cls._instance = None

    def is_installed(self, app_id: str) -> bool:
        return app_id in self._installed

    def install(self, app_id: str):
        if app_id in self._installed:
            return
        self._installed.add(app_id)
        self._save()
        self.changed.emit()

    def uninstall(self, app_id: str):
        if app_id not in self._installed:
            return
        self._installed.discard(app_id)
        self._save()
        self.changed.emit()

    def _load(self):
        if not self._data_file.exists():
            return
        try:
            data = json.loads(self._data_file.read_text(encoding="utf-8"))
            self._installed = set(data.get("installed", []))
        except (json.JSONDecodeError, OSError, TypeError):
            self._installed = set()

    def _save(self):
        try:
            self._data_file.parent.mkdir(parents=True, exist_ok=True)
            self._data_file.write_text(
                json.dumps({"installed": sorted(self._installed)}, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except OSError:
            pass
