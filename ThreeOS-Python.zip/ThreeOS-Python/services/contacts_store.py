"""
ContactsStore — общее хранилище контактов ThreeOS.

И Контакты, и СМС читают контакты именно отсюда, поэтому оба приложения
всегда видят одни и те же данные (добавил контакт в одном — он сразу
доступен в другом, через сигнал contacts_changed). Хранится в JSON-файле
в домашней папке пользователя, так что контакты не пропадают между
запусками приложения.
"""
import json
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import QObject, Signal

DATA_DIR = Path.home() / ".threeos"
CONTACTS_FILE = DATA_DIR / "contacts.json"

AVATAR_COLORS = ["#7c5cff", "#22d3b8", "#ff6b6b", "#f5a623", "#4f8cff", "#e879c9"]


@dataclass
class Contact:
    id: str
    name: str
    phone: str = ""
    email: str = ""
    note: str = ""
    color: str = "#7c5cff"
    device_id: Optional[str] = None  # если задан — контакт привязан к реальному ThreeOS в сети

    def initial(self) -> str:
        stripped = self.name.strip()
        return stripped[:1].upper() if stripped else "?"


class ContactsStore(QObject):
    contacts_changed = Signal()

    _instance: Optional["ContactsStore"] = None

    def __init__(self, data_file: Optional[Path] = None):
        super().__init__()
        self._data_file = data_file or CONTACTS_FILE
        self._contacts: Dict[str, Contact] = {}
        self._load()
        if not self._contacts:
            self._seed_demo_contacts()

    @classmethod
    def instance(cls) -> "ContactsStore":
        if cls._instance is None:
            cls._instance = ContactsStore()
        return cls._instance

    @classmethod
    def reset_instance_for_tests(cls):
        cls._instance = None

    def all(self) -> List[Contact]:
        return sorted(self._contacts.values(), key=lambda c: c.name.lower())

    def get(self, contact_id: str) -> Optional[Contact]:
        return self._contacts.get(contact_id)

    def find_by_device_id(self, device_id: str) -> Optional[Contact]:
        for contact in self._contacts.values():
            if contact.device_id == device_id:
                return contact
        return None

    def find_by_phone(self, phone: str) -> Optional[Contact]:
        phone = phone.strip()
        for contact in self._contacts.values():
            if contact.phone.strip() == phone:
                return contact
        return None

    def add(self, name: str, phone: str = "", email: str = "", note: str = "", device_id: Optional[str] = None) -> Contact:
        contact_id = uuid.uuid4().hex[:10]
        color = AVATAR_COLORS[len(self._contacts) % len(AVATAR_COLORS)]
        contact = Contact(id=contact_id, name=name, phone=phone, email=email, note=note, color=color, device_id=device_id)
        self._contacts[contact_id] = contact
        self._save()
        self.contacts_changed.emit()
        return contact

    def update(self, contact_id: str, **fields) -> bool:
        contact = self._contacts.get(contact_id)
        if contact is None:
            return False
        for key, value in fields.items():
            if hasattr(contact, key):
                setattr(contact, key, value)
        self._save()
        self.contacts_changed.emit()
        return True

    def remove(self, contact_id: str) -> bool:
        if contact_id not in self._contacts:
            return False
        del self._contacts[contact_id]
        self._save()
        self.contacts_changed.emit()
        return True

    def _load(self):
        if not self._data_file.exists():
            return
        try:
            raw = json.loads(self._data_file.read_text(encoding="utf-8"))
            for item in raw:
                contact = Contact(**item)
                self._contacts[contact.id] = contact
        except (json.JSONDecodeError, OSError, TypeError):
            # Повреждённый файл не должен ронять приложение — начинаем
            # с чистого листа (файл перезапишется при следующем изменении).
            self._contacts = {}

    def _save(self):
        try:
            self._data_file.parent.mkdir(parents=True, exist_ok=True)
            data = [asdict(c) for c in self._contacts.values()]
            self._data_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass  # диск недоступен для записи — продолжаем работать в памяти

    def _seed_demo_contacts(self):
        demo = [
            ("Мама", "+7 700 111 2233", "", "Перезвонить вечером"),
            ("Алексей", "+7 701 222 3344", "alexey@example.com", "Коллега по проекту"),
            ("ThreeOS", "", "", "Служба поддержки системы"),
        ]
        for name, phone, email, note in demo:
            self.add(name, phone, email, note)
