"""
MessagesStore — общее хранилище переписки ThreeOS.

Настоящий SMS через оператора связи в desktop-приложении невозможен без
сотового модема, поэтому это локальная переписка, привязанная к контактам
из ContactsStore. Хранится в JSON-файле в домашней папке пользователя.
"""
import json
import uuid
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import QObject, Signal

DATA_DIR = Path.home() / ".threeos"
MESSAGES_FILE = DATA_DIR / "messages.json"


@dataclass
class Message:
    id: str
    contact_id: str
    outgoing: bool
    text: str
    timestamp: str  # ISO 8601
    delivered: bool = True
    queued: bool = False   # доставлено не сразу, а поставлено в очередь сервером
    pending: bool = False  # ждём асинхронного подтверждения от сервера


class MessagesStore(QObject):
    messages_changed = Signal(str)  # id контакта, чей диалог изменился

    _instance: Optional["MessagesStore"] = None

    def __init__(self, data_file: Optional[Path] = None):
        super().__init__()
        self._data_file = data_file or MESSAGES_FILE
        self._messages: Dict[str, List[Message]] = {}
        self._load()

    @classmethod
    def instance(cls) -> "MessagesStore":
        if cls._instance is None:
            cls._instance = MessagesStore()
        return cls._instance

    @classmethod
    def reset_instance_for_tests(cls):
        cls._instance = None

    def thread(self, contact_id: str) -> List[Message]:
        return list(self._messages.get(contact_id, []))

    def last_message(self, contact_id: str) -> Optional[Message]:
        thread = self._messages.get(contact_id)
        return thread[-1] if thread else None

    def send(self, contact_id: str, text: str, delivered: bool = True, queued: bool = False, pending: bool = False) -> Message:
        return self._append(contact_id, text, outgoing=True, delivered=delivered, queued=queued, pending=pending)

    def receive(self, contact_id: str, text: str) -> Message:
        return self._append(contact_id, text, outgoing=False, delivered=True)

    def update_status(self, contact_id: str, message_id: str, delivered: bool, queued: bool = False) -> bool:
        """Обновляет статус ранее отправленного сообщения, когда приходит
        асинхронный ответ от сервера (см. AccountService.send_result)."""
        for msg in self._messages.get(contact_id, []):
            if msg.id == message_id:
                msg.delivered = delivered
                msg.queued = queued
                msg.pending = False
                self._save()
                self.messages_changed.emit(contact_id)
                return True
        return False

    def _append(self, contact_id: str, text: str, outgoing: bool, delivered: bool = True,
                queued: bool = False, pending: bool = False) -> Message:
        msg = Message(
            id=uuid.uuid4().hex[:10],
            contact_id=contact_id,
            outgoing=outgoing,
            text=text,
            timestamp=datetime.now().isoformat(timespec="seconds"),
            delivered=delivered,
            queued=queued,
            pending=pending,
        )
        self._messages.setdefault(contact_id, []).append(msg)
        self._save()
        self.messages_changed.emit(contact_id)
        return msg

    def _load(self):
        if not self._data_file.exists():
            return
        try:
            raw = json.loads(self._data_file.read_text(encoding="utf-8"))
            for contact_id, items in raw.items():
                self._messages[contact_id] = [Message(**item) for item in items]
        except (json.JSONDecodeError, OSError, TypeError):
            self._messages = {}

    def _save(self):
        try:
            self._data_file.parent.mkdir(parents=True, exist_ok=True)
            data = {cid: [asdict(m) for m in msgs] for cid, msgs in self._messages.items()}
            self._data_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass
