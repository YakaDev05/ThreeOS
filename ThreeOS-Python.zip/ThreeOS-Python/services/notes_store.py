"""
NotesStore — хранилище заметок для приложения Заметки. Тот же паттерн,
что и у ContactsStore/MessagesStore: персистентность в JSON + сигнал
изменений для живого обновления интерфейса.
"""
import json
import uuid
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import QObject, Signal

DATA_DIR = Path.home() / ".threeos"
NOTES_FILE = DATA_DIR / "notes.json"


@dataclass
class Note:
    id: str
    title: str
    body: str
    updated_at: str


class NotesStore(QObject):
    notes_changed = Signal()

    _instance: Optional["NotesStore"] = None

    def __init__(self, data_file: Optional[Path] = None):
        super().__init__()
        self._data_file = data_file or NOTES_FILE
        self._notes: Dict[str, Note] = {}
        self._load()

    @classmethod
    def instance(cls) -> "NotesStore":
        if cls._instance is None:
            cls._instance = NotesStore()
        return cls._instance

    @classmethod
    def reset_instance_for_tests(cls):
        cls._instance = None

    def all(self) -> List[Note]:
        return sorted(self._notes.values(), key=lambda n: n.updated_at, reverse=True)

    def get(self, note_id: str) -> Optional[Note]:
        return self._notes.get(note_id)

    def create(self, title: str = "Новая заметка", body: str = "") -> Note:
        note = Note(id=uuid.uuid4().hex[:10], title=title, body=body,
                     updated_at=datetime.now().isoformat(timespec="seconds"))
        self._notes[note.id] = note
        self._save()
        self.notes_changed.emit()
        return note

    def update(self, note_id: str, title: Optional[str] = None, body: Optional[str] = None) -> bool:
        note = self._notes.get(note_id)
        if note is None:
            return False
        if title is not None:
            note.title = title
        if body is not None:
            note.body = body
        note.updated_at = datetime.now().isoformat(timespec="seconds")
        self._save()
        self.notes_changed.emit()
        return True

    def remove(self, note_id: str) -> bool:
        if note_id not in self._notes:
            return False
        del self._notes[note_id]
        self._save()
        self.notes_changed.emit()
        return True

    def _load(self):
        if not self._data_file.exists():
            return
        try:
            raw = json.loads(self._data_file.read_text(encoding="utf-8"))
            for item in raw:
                note = Note(**item)
                self._notes[note.id] = note
        except (json.JSONDecodeError, OSError, TypeError):
            self._notes = {}

    def _save(self):
        try:
            self._data_file.parent.mkdir(parents=True, exist_ok=True)
            data = [asdict(n) for n in self._notes.values()]
            self._data_file.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass
