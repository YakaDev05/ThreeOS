"""
AccountService — подключение к серверу учётных записей ThreeOS
(server/threeos_server.py): регистрация, вход, отправка и приём сообщений
по номеру телефона через сервер — в отличие от NetworkService (LAN,
без сервера), это работает через интернет между любыми сетями, если
сервер запущен где-то с доступным адресом.

Персистентная связь: пока приложение открыто и вы вошли в аккаунт,
соединение с сервером держится постоянно, поэтому входящие сообщения
приходят сразу, а не только при следующем запуске.
"""
import json
import uuid
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, Signal
from PySide6.QtNetwork import QTcpSocket

CONFIG_FILE = Path.home() / ".threeos" / "server_config.json"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 51950


class AccountService(QObject):
    connection_changed = Signal(bool)            # подключены ли мы сейчас к серверу
    register_result = Signal(bool, str)           # ok, reason
    login_result = Signal(bool, str)               # ok, reason
    send_result = Signal(str, bool, bool)          # client_msg_id, ok, queued
    message_received = Signal(str, str, str)       # from_phone, from_name, text

    _instance: Optional["AccountService"] = None

    def __init__(self, config_file: Optional[Path] = None):
        super().__init__()
        self._config_file = config_file or CONFIG_FILE
        self._host, self._port = self._load_config()

        self.phone: Optional[str] = None
        self.logged_in: bool = False

        self._socket = QTcpSocket(self)
        self._socket.readyRead.connect(self._on_ready_read)
        self._socket.connected.connect(lambda: self.connection_changed.emit(True))
        self._socket.disconnected.connect(self._on_disconnected)
        self._buffer = b""

    @classmethod
    def instance(cls) -> "AccountService":
        if cls._instance is None:
            cls._instance = AccountService()
        return cls._instance

    @classmethod
    def reset_instance_for_tests(cls):
        cls._instance = None

    # ---------- настройки сервера ----------
    def server_address(self):
        return self._host, self._port

    def set_server_address(self, host: str, port: int):
        self._host, self._port = host, port
        self._save_config()

    def is_connected(self) -> bool:
        return self._socket.state() == QTcpSocket.SocketState.ConnectedState

    def ensure_connected(self, timeout_ms: int = 2000) -> bool:
        if self.is_connected():
            return True
        self._socket.connectToHost(self._host, self._port)
        return self._socket.waitForConnected(timeout_ms)

    # ---------- аккаунт ----------
    def register(self, phone: str, password: str, name: str):
        if not self.ensure_connected():
            self.register_result.emit(False, "Не удалось подключиться к серверу")
            return
        self._send({"type": "register", "phone": phone, "password": password, "name": name})

    def login(self, phone: str, password: str):
        if not self.ensure_connected():
            self.login_result.emit(False, "Не удалось подключиться к серверу")
            return
        self._pending_login_phone = phone
        self._send({"type": "login", "phone": phone, "password": password})

    def logout(self):
        self.logged_in = False
        self.phone = None
        self._socket.disconnectFromHost()

    def send_message(self, to_phone: str, text: str) -> str:
        """Отправляет сообщение асинхронно; результат придёт через сигнал
        send_result. Возвращает client_msg_id для сопоставления с ним."""
        client_msg_id = uuid.uuid4().hex[:12]
        if not self.logged_in or not self.ensure_connected():
            self.send_result.emit(client_msg_id, False, False)
            return client_msg_id
        self._send({"type": "send_message", "to_phone": to_phone, "text": text, "client_msg_id": client_msg_id})
        return client_msg_id

    # ---------- протокол ----------
    def _send(self, obj: dict):
        line = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
        self._socket.write(line)

    def _on_ready_read(self):
        self._buffer += bytes(self._socket.readAll())
        while b"\n" in self._buffer:
            line, self._buffer = self._buffer.split(b"\n", 1)
            if not line.strip():
                continue
            try:
                data = json.loads(line.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            self._handle_message(data)

    def _handle_message(self, data: dict):
        mtype = data.get("type")
        if mtype == "register_result":
            self.register_result.emit(bool(data.get("ok")), data.get("reason", ""))
        elif mtype == "login_result":
            ok = bool(data.get("ok"))
            if ok:
                self.logged_in = True
                self.phone = getattr(self, "_pending_login_phone", None)
            self.login_result.emit(ok, data.get("reason", ""))
        elif mtype == "send_result":
            self.send_result.emit(data.get("client_msg_id", ""), bool(data.get("ok")), bool(data.get("queued")))
        elif mtype == "message":
            self.message_received.emit(data.get("from_phone", ""), data.get("from_name", ""), data.get("text", ""))

    def _on_disconnected(self):
        self.logged_in = False
        self.connection_changed.emit(False)

    # ---------- конфиг ----------
    def _load_config(self):
        if self._config_file.exists():
            try:
                data = json.loads(self._config_file.read_text(encoding="utf-8"))
                return data.get("host", DEFAULT_HOST), int(data.get("port", DEFAULT_PORT))
            except (json.JSONDecodeError, OSError, TypeError, ValueError):
                pass
        return DEFAULT_HOST, DEFAULT_PORT

    def _save_config(self):
        try:
            self._config_file.parent.mkdir(parents=True, exist_ok=True)
            self._config_file.write_text(
                json.dumps({"host": self._host, "port": self._port}, indent=2), encoding="utf-8"
            )
        except OSError:
            pass
