"""
Identity — постоянный локальный идентификатор этого экземпляра ThreeOS.

device_id создаётся один раз и хранится в ~/.threeos/identity.json — по нему
другие ThreeOS в локальной сети узнают "это тот же человек, что и вчера",
даже если он сменил имя. display_name — то, что видят другие в списке
"Люди в сети".
"""
import getpass
import json
import uuid
from pathlib import Path
from typing import Optional

DATA_DIR = Path.home() / ".threeos"
IDENTITY_FILE = DATA_DIR / "identity.json"


class Identity:
    _instance: Optional["Identity"] = None

    def __init__(self, data_file: Optional[Path] = None):
        self._data_file = data_file or IDENTITY_FILE
        self.device_id: str = ""
        self.display_name: str = ""
        self._load_or_create()

    @classmethod
    def instance(cls) -> "Identity":
        if cls._instance is None:
            cls._instance = Identity()
        return cls._instance

    @classmethod
    def reset_instance_for_tests(cls):
        cls._instance = None

    def set_display_name(self, name: str):
        name = name.strip()
        if name:
            self.display_name = name
            self._save()

    def _load_or_create(self):
        if self._data_file.exists():
            try:
                data = json.loads(self._data_file.read_text(encoding="utf-8"))
                device_id = data.get("device_id")
                display_name = data.get("display_name")
                if device_id and display_name:
                    self.device_id = device_id
                    self.display_name = display_name
                    return
            except (json.JSONDecodeError, OSError, TypeError):
                pass
        self.device_id = uuid.uuid4().hex
        self.display_name = self._default_name()
        self._save()

    def _default_name(self) -> str:
        try:
            name = getpass.getuser()
            return name if name else "Пользователь ThreeOS"
        except Exception:
            return "Пользователь ThreeOS"

    def _save(self):
        try:
            self._data_file.parent.mkdir(parents=True, exist_ok=True)
            payload = {"device_id": self.device_id, "display_name": self.display_name}
            self._data_file.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass
