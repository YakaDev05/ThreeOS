"""
Реестр всех "установленных" приложений ThreeOS.
Рабочий стол, панель задач и Магазин приложений строятся динамически на
основе этого списка — чтобы добавить новое приложение в систему, достаточно
зарегистрировать его здесь (см. register_apps() в main.py), а не переписывать
код оболочки.
"""
from typing import Dict, List, Optional

from core.iapp import IApp


class AppRegistry:
    _instance: Optional["AppRegistry"] = None

    def __init__(self):
        self._apps: Dict[str, IApp] = {}

    @classmethod
    def instance(cls) -> "AppRegistry":
        if cls._instance is None:
            cls._instance = AppRegistry()
        return cls._instance

    def register_app(self, app: IApp) -> None:
        self._apps[app.id()] = app

    def all_apps(self) -> List[IApp]:
        return list(self._apps.values())

    def app_by_id(self, app_id: str) -> Optional[IApp]:
        return self._apps.get(app_id)
