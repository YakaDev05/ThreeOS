"""
Главное окно ThreeOS — "рабочий стол". Содержит область для окон приложений
(QMdiArea), иконки на рабочем столе и панель задач. Полностью управляется
данными из AppRegistry: ничего здесь не зашито под конкретное приложение.
"""
from typing import Optional

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QBrush
from PySide6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QMdiArea, QToolButton, QFrame

from core.theme import Theme
from shell.task_bar import TaskBar
from shell.app_registry import AppRegistry
from services.app_bus import AppBus
from services.installed_apps_store import InstalledAppsStore


class DesktopWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ThreeOS")
        self.resize(1280, 800)
        self._cascade_counter = 0
        self._icons_container: Optional[QWidget] = None

        central = QWidget(self)
        vlayout = QVBoxLayout(central)
        vlayout.setContentsMargins(0, 0, 0, 0)
        vlayout.setSpacing(0)

        self._mdi_area = QMdiArea(central)
        self._mdi_area.setBackground(QBrush(Theme.bg_base))
        self._mdi_area.setFrameShape(QFrame.Shape.NoFrame)

        self._task_bar = TaskBar(central)
        self._task_bar.app_launch_requested.connect(self.launch_app)

        vlayout.addWidget(self._mdi_area, 1)
        vlayout.addWidget(self._task_bar, 0)
        central.setLayout(vlayout)

        self.setCentralWidget(central)

        self._setup_desktop_icons()
        InstalledAppsStore.instance().changed.connect(self._setup_desktop_icons)

        # Позволяет одному приложению попросить открыть другое в конкретном
        # состоянии, не имея на него прямой ссылки (см. services/app_bus.py).
        AppBus.instance().open_app_requested.connect(self.launch_app)

    def _visible_apps(self):
        installed = InstalledAppsStore.instance()
        return [app for app in AppRegistry.instance().all_apps() if app.is_core() or installed.is_installed(app.id())]

    def _setup_desktop_icons(self):
        if self._icons_container is not None:
            self._icons_container.deleteLater()

        container = QWidget(self._mdi_area.viewport())
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        for app in self._visible_apps():
            btn = QToolButton(container)
            btn.setText(f"{app.icon_emoji()}\n{app.name()}")
            btn.setFont(QFont(Theme.font_ui, 9))
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setFixedSize(92, 78)
            btn.setStyleSheet(
                f"QToolButton {{ color: {Theme.text_primary.name()}; background: transparent;"
                f" border: none; border-radius: 10px; padding-top: 6px; }}"
                f"QToolButton:hover {{ background: rgba(255,255,255,28); }}"
                f"QToolButton:pressed {{ background: rgba(255,255,255,45); }}"
            )
            btn.clicked.connect(lambda checked=False, app_id=app.id(): self.launch_app(app_id))
            layout.addWidget(btn)

        container.setLayout(layout)
        container.move(18, 18)
        container.resize(112, 640)
        container.show()
        self._icons_container = container

    def launch_app(self, app_id: str, context: Optional[dict] = None):
        app = AppRegistry.instance().app_by_id(app_id)
        if app is None:
            return

        app_widget = app.create_widget(context=context)
        sub = self._mdi_area.addSubWindow(app_widget)
        sub.setWindowTitle(f"{app.icon_emoji()}  {app.name()}")
        sub.resize(app.preferred_size())

        offset = (self._cascade_counter % 8) * 28
        sub.move(150 + offset, 24 + offset)
        self._cascade_counter += 1

        sub.show()
        app_widget.setFocus()
