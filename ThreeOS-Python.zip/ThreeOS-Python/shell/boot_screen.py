"""
Экран загрузки ThreeOS: показывается на старте, затем испускает сигнал
boot_finished и main.py переключается на рабочий стол.
"""
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QProgressBar

from core.theme import Theme


class BootScreen(QWidget):
    boot_finished = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("ThreeOS")
        self.resize(1280, 800)
        self.setStyleSheet(f"background-color: {Theme.bg_base.name()};")

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(6)

        title = QLabel("ThreeOS", self)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setFont(QFont(Theme.font_display, 46, QFont.Weight.DemiBold))
        title.setStyleSheet(f"color: {Theme.text_primary.name()}; letter-spacing: 2px;")

        subtitle = QLabel("от Said (Yaka) Hamidov", self)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setFont(QFont(Theme.font_ui, 11))
        subtitle.setStyleSheet(f"color: {Theme.text_muted.name()}; margin-bottom: 36px;")

        self._progress = QProgressBar(self)
        self._progress.setRange(0, 100)
        self._progress.setValue(0)
        self._progress.setFixedWidth(320)
        self._progress.setFixedHeight(6)
        self._progress.setTextVisible(False)
        self._progress.setStyleSheet(
            f"QProgressBar {{ background-color: {Theme.bg_surface_alt.name()}; border-radius: 3px; }}"
            f"QProgressBar::chunk {{ background-color: {Theme.accent.name()}; border-radius: 3px; }}"
        )

        status = QLabel("Загрузка ThreeOS…", self)
        status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        status.setFont(QFont(Theme.font_ui, 9))
        status.setStyleSheet(f"color: {Theme.text_muted.name()}; margin-top: 14px;")

        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addWidget(self._progress, 0, Qt.AlignmentFlag.AlignHCenter)
        layout.addWidget(status)
        self.setLayout(layout)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(35)

    def _tick(self):
        value = self._progress.value() + 5
        if value >= 100:
            self._progress.setValue(100)
            self._timer.stop()
            self.boot_finished.emit()
        else:
            self._progress.setValue(value)
