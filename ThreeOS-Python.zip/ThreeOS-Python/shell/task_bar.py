"""
Панель задач ThreeOS: кнопка запуска приложений (со списком всех
зарегистрированных в AppRegistry) и часы. Ничего не знает о конкретных
приложениях — только об интерфейсе IApp.
"""
from PySide6.QtCore import Qt, QTimer, QDateTime, Signal
from PySide6.QtGui import QFont, QAction
from PySide6.QtWidgets import QWidget, QHBoxLayout, QLabel, QPushButton, QMenu

from core.theme import Theme
from shell.app_registry import AppRegistry
from services.installed_apps_store import InstalledAppsStore


class TaskBar(QWidget):
    app_launch_requested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(52)
        self.setStyleSheet(
            f"background-color: {Theme.bg_surface.name()}; border-top: 1px solid {Theme.border.name()};"
        )

        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 6, 14, 6)
        layout.setSpacing(12)

        self._start_button = QPushButton("☰   ThreeOS", self)
        self._start_button.setFont(QFont(Theme.font_ui, 10, QFont.Weight.DemiBold))
        self._start_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self._start_button.setStyleSheet(
            f"QPushButton {{ background-color: {Theme.accent.name()}; color: white; border: none;"
            f" border-radius: 8px; padding: 8px 18px; }}"
            f"QPushButton:hover {{ background-color: {Theme.accent_hover.name()}; }}"
            f"QPushButton::menu-indicator {{ image: none; width: 0; }}"
        )
        self._build_start_menu()

        self._clock = QLabel(self)
        self._clock.setFont(QFont(Theme.font_ui, 10))
        self._clock.setStyleSheet(f"color: {Theme.text_muted.name()};")
        self._update_clock()

        layout.addWidget(self._start_button)
        layout.addStretch()
        layout.addWidget(self._clock)
        self.setLayout(layout)

        self._clock_timer = QTimer(self)
        self._clock_timer.timeout.connect(self._update_clock)
        self._clock_timer.start(1000)

        InstalledAppsStore.instance().changed.connect(self._build_start_menu)

    def _build_start_menu(self):
        menu = QMenu(self._start_button)
        menu.setFont(QFont(Theme.font_ui, 10))
        menu.setStyleSheet(
            f"QMenu {{ background-color: {Theme.bg_surface_alt.name()}; color: {Theme.text_primary.name()};"
            f" border: 1px solid {Theme.border.name()}; padding: 6px; border-radius: 8px; }}"
            f"QMenu::item {{ padding: 8px 26px 8px 12px; border-radius: 6px; }}"
            f"QMenu::item:selected {{ background-color: {Theme.accent.name()}; color: white; }}"
        )

        installed = InstalledAppsStore.instance()
        for app in AppRegistry.instance().all_apps():
            if not (app.is_core() or installed.is_installed(app.id())):
                continue
            action = QAction(f"{app.icon_emoji()}   {app.name()}", menu)
            # app_id=app.id() фиксирует значение на момент создания лямбды —
            # без этого все пункты меню запускали бы последнее приложение в списке.
            action.triggered.connect(
                lambda checked=False, app_id=app.id(): self.app_launch_requested.emit(app_id)
            )
            menu.addAction(action)

        self._start_button.setMenu(menu)

    def _update_clock(self):
        self._clock.setText(QDateTime.currentDateTime().toString("HH:mm:ss    dddd, d MMMM"))
